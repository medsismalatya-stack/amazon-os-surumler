"use strict";
(() => {
  // src/engine/rational.ts
  var abs = (x) => x < 0n ? -x : x;
  var gcd = (a, b) => {
    a = abs(a);
    b = abs(b);
    while (b !== 0n) [a, b] = [b, a % b];
    return a;
  };
  var toBigInt = (x, label) => {
    if (typeof x === "bigint") return x;
    if (!Number.isSafeInteger(x)) {
      throw new RangeError(`${label} tam say\u0131 olmal\u0131: ${x}`);
    }
    return BigInt(x);
  };
  var Q = class _Q {
    n;
    d;
    constructor(n, d) {
      if (d === 0n) throw new RangeError("Payda s\u0131f\u0131r olamaz");
      if (d < 0n) {
        n = -n;
        d = -d;
      }
      const g = gcd(n, d) || 1n;
      this.n = n / g;
      this.d = d / g;
    }
    static ZERO = new _Q(0n, 1n);
    static ONE = new _Q(1n, 1n);
    /** Tam sayı veya kesir: Q.of(3), Q.of(59700, 101) */
    static of(n, d = 1n) {
      return new _Q(toBigInt(n, "pay"), toBigInt(d, "payda"));
    }
    /** Kuruş cinsinden tutar → TL. Q.kurus(12900) = 129 */
    static kurus(k) {
      return new _Q(toBigInt(k, "kuru\u015F"), 100n);
    }
    /** Ondalık metin → kesin kesir. Q.dec("0.09") = 9/100. Virgül kabul edilmez. */
    static dec(s) {
      const m = /^(-)?(\d+)(?:\.(\d+))?$/.exec(s.trim());
      if (!m) throw new RangeError(`Ge\xE7ersiz ondal\u0131k say\u0131: "${s}"`);
      const [, sign, int, frac = ""] = m;
      const n = BigInt(int + frac) * (sign ? -1n : 1n);
      return new _Q(n, 10n ** BigInt(frac.length));
    }
    add(o) {
      return new _Q(this.n * o.d + o.n * this.d, this.d * o.d);
    }
    sub(o) {
      return new _Q(this.n * o.d - o.n * this.d, this.d * o.d);
    }
    mul(o) {
      return new _Q(this.n * o.n, this.d * o.d);
    }
    div(o) {
      if (o.n === 0n) throw new RangeError("S\u0131f\u0131ra b\xF6lme");
      return new _Q(this.n * o.d, this.d * o.n);
    }
    neg() {
      return new _Q(-this.n, this.d);
    }
    cmp(o) {
      const l = this.n * o.d;
      const r = o.n * this.d;
      return l < r ? -1 : l > r ? 1 : 0;
    }
    eq(o) {
      return this.n === o.n && this.d === o.d;
    }
    isZero() {
      return this.n === 0n;
    }
    sign() {
      return this.n < 0n ? -1 : this.n > 0n ? 1 : 0;
    }
    /** Yukarı yuvarlama (tavan). Sipariş adedi için. */
    ceil() {
      const q = this.n / this.d;
      return this.n % this.d !== 0n && this.n > 0n ? q + 1n : q;
    }
    /** Kesin gösterim: "-571173/10100" */
    toString() {
      return this.d === 1n ? `${this.n}` : `${this.n}/${this.d}`;
    }
    /**
     * YALNIZCA GÖSTERİM içindir. Yarım değerler sıfırdan uzağa yuvarlanır.
     * Hesaplarda kullanılmaz.
     */
    toFixed(digits = 2) {
      const scale = 10n ** BigInt(digits);
      const x = this.n * scale;
      let q = x / this.d;
      const r = abs(x % this.d);
      if (2n * r >= this.d) q += this.n < 0n ? -1n : 1n;
      const neg = q < 0n;
      const s = abs(q).toString().padStart(digits + 1, "0");
      const body = digits === 0 ? s : `${s.slice(0, -digits)}.${s.slice(-digits)}`;
      return (neg ? "-" : "") + body;
    }
  };

  // src/engine/profit.ts
  var STOPAJ_RATE = Q.dec("0.01");
  var AMAZON_FEE_VAT = Q.dec("0.20");

  // src/engine/buybox.ts
  var UNDERCUT_SHARE_MAX = Q.of(1n, 5n);
  var MIN_BELOW_TOLERANCE = Q.of(5n, 100n);

  // src/core/listing-quality.ts
  var RISKY = [
    { code: "riskli_yas", re: /her\s+yaş(a|tan|\s+grubu)/iu, text: '"her ya\u015Fa uygun" ifadesi: k\xFC\xE7\xFCk par\xE7al\u0131 \xFCr\xFCnlerde ya\u015F uyar\u0131s\u0131yla \xE7eli\u015Fir', level: "hata" },
    { code: "riskli_saglik", re: new RegExp("(?<!\\p{L})(migren|sin\xFCzit|tedavi|iyile\u015Ftir|\u015Fifa)", "iu"), text: "sa\u011Fl\u0131k / tedavi iddias\u0131 olabilir", level: "hata" },
    { code: "riskli_mevzuat", re: /gıda\s+kodeksi/iu, text: '"G\u0131da Kodeksi" ifadesi: \xFCr\xFCn t\xFCr\xFCne uygun mevzuat m\u0131 kontrol edin', level: "uyari" }
  ];
  var OTHER_BRANDS = ["lego", "duplo", "tetris", "dyson"];
  var BRAND_RE = new RegExp(`(?<!\\p{L})(${OTHER_BRANDS.join("|")})(?!\\p{L})`, "giu");
  var LOOKS_LIKE = new RegExp("^\\s*(\\p{L}+\\s+){0,2}(par\xE7a(s\u0131|lar\u0131)?|yedek|benzeri|muadili|replika|orijinal)(?!\\p{L})", "iu");
  var IMAGE_RULES = { zoomMin: 1e3, recommended: 1600, minCount: 6, fill: Q.of(85, 100) };

  // src/core/ad-terms.ts
  function adPageOf(pathname) {
    const m = /\/sp\/campaigns\/([A-Z0-9]{10,40})\/ad-groups\/([A-Z0-9]{10,40})\/(search-terms|ads)\/?$/.exec(pathname);
    return m ? { campaign: m[1], adGroup: m[2], tab: m[3] } : null;
  }
  var MONTHS = ["oca", "\u015Fub", "mar", "nis", "may", "haz", "tem", "a\u011Fu", "eyl", "eki", "kas", "ara"];
  var iso = (y, m, d) => {
    const t = new Date(Date.UTC(y, m, d));
    return t.getUTCFullYear() === y && t.getUTCMonth() === m && t.getUTCDate() === d ? t.toISOString().slice(0, 10) : null;
  };
  function parseAdRange(text) {
    const part = (s) => {
      const m = new RegExp("^(\\d{1,2})\\s+(\\p{L}{3})\\p{L}*\\.?(?:\\s+(\\d{4}))?$", "u").exec(s.trim());
      if (!m) return null;
      const mo = MONTHS.indexOf(m[2].toLocaleLowerCase("tr-TR"));
      return mo < 0 ? null : { d: Number(m[1]), mo, y: m[3] ? Number(m[3]) : null };
    };
    const ps = text.split(/\s[-–]\s/);
    if (ps.length < 1 || ps.length > 2) return null;
    const b = part(ps[ps.length - 1]);
    const a = ps.length === 2 ? part(ps[0]) : b;
    if (!a || !b || b.y === null) return null;
    const from = iso(a.y ?? b.y, a.mo, a.d), to = iso(b.y, b.mo, b.d);
    return from && to && from <= to ? { from, to } : null;
  }
  function parseTrInt(s) {
    const t = s.trim();
    if (!/^\d{1,3}(\.\d{3})*$|^\d+$/.test(t)) return null;
    const n = Number(t.replace(/\./g, ""));
    return Number.isSafeInteger(n) ? n : null;
  }
  function parseTrKurus(s) {
    const m = /^[₺\s]*(\d{1,3}(?:\.\d{3})*|\d+),(\d{2})$/.exec(s.trim());
    if (!m) return null;
    return String(BigInt(m[1].replace(/\./g, "")) * 100n + BigInt(m[2]));
  }
  function adTermRow(c) {
    const term = c.term.trim().replace(/\s+/g, " ");
    const dash = (s) => /^[-–—]$/.test(s.trim());
    const impressions = parseTrInt(c.impressions), clicks = parseTrInt(c.clicks), orders = dash(c.orders) ? 0 : parseTrInt(c.orders);
    const spend = dash(c.spend) && clicks === 0 ? "0" : parseTrKurus(c.spend);
    const sales = dash(c.sales) && orders === 0 ? "0" : parseTrKurus(c.sales);
    if (dash(c.orders) && !dash(c.sales)) return null;
    if (!term || term.length > 250 || impressions === null || clicks === null || orders === null || spend === null || sales === null) return null;
    return { term, target: c.target.trim().replace(/\s+/g, " ").slice(0, 120), impressions, clicks, spend_kurus: spend, orders, sales_kurus: sales };
  }
  var adAsinOf = (cell) => /(?:^|\s)(B0[A-Z0-9]{8})(?:\s|$)/.exec(cell.trim())?.[1] ?? null;

  // extension/src/content-ads.ts
  var send = (m) => chrome.runtime.sendMessage(m).catch((e) => ({ ok: false, error: e.message }));
  var host = document.createElement("div");
  host.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:2147483647;";
  var root = host.attachShadow({ mode: "closed" });
  root.innerHTML = `<style>
  .box{font:13px/1.45 system-ui,Segoe UI,Arial,sans-serif;background:#fff;color:#111;border:1px solid #c9ced6;border-radius:10px;box-shadow:0 6px 20px rgba(0,0,0,.2);padding:10px 12px;width:320px}
  .head{font-weight:600;margin-bottom:4px}.ok{color:#0a7d32}.err{color:#b3261e}.muted{color:#666;font-size:12px}
</style><div class="box"><div class="head">AMAZON OS \xB7 Reklam</div><div id="msg"></div><div id="sub" class="muted"></div></div>`;
  var $ = (id) => root.getElementById(id);
  var show = (msg, cls, sub = "") => {
    $("msg").textContent = msg;
    $("msg").className = cls;
    $("sub").textContent = sub;
  };
  var key = "";
  var terms = /* @__PURE__ */ new Map();
  var sentTerms = /* @__PURE__ */ new Set();
  var asins = /* @__PURE__ */ new Set();
  var sentAsins = 0;
  var saved = null;
  var busy = false;
  var groupName = () => (document.querySelector("h1")?.textContent ?? "").replace(/\s+/g, " ").replace(/^Reklam grubu:\s*/i, "").trim() || null;
  var rangeOnPage = () => {
    for (const b of Array.from(document.querySelectorAll("button"))) {
      const r = parseAdRange((b.innerText ?? b.textContent ?? "").replace(/\s+/g, " ").trim());
      if (r) return r;
    }
    return null;
  };
  var totalOnPage = () => {
    const m = /Toplam:\s*([\d.]+)/.exec(document.body.innerText ?? "");
    return m ? parseTrInt(m[1]) : null;
  };
  function gridRows() {
    const by = /* @__PURE__ */ new Map();
    for (const r of Array.from(document.querySelectorAll(".ag-row[row-id]"))) {
      const id = r.getAttribute("row-id");
      const rec = by.get(id) ?? {};
      for (const c of Array.from(r.querySelectorAll("[col-id]"))) rec[c.getAttribute("col-id")] = (c.innerText ?? c.textContent ?? "").replace(/\s+/g, " ").trim();
      by.set(id, rec);
    }
    return [...by.values()];
  }
  async function tick() {
    const page = adPageOf(location.pathname);
    if (!page) {
      host.remove();
      key = "";
      return;
    }
    if (!host.isConnected) document.documentElement.appendChild(host);
    if (page.tab === "ads") {
      if (key !== `ads:${page.adGroup}`) {
        key = `ads:${page.adGroup}`;
        asins.clear();
        sentAsins = 0;
      }
      for (const r of gridRows()) {
        const a = adAsinOf(r.asin ?? "");
        if (a) asins.add(a);
      }
      if (asins.size === 0) return show("Reklamlar okunuyor\u2026", "muted");
      if (asins.size > sentAsins && !busy) {
        busy = true;
        const r = await send({ type: "adAsins", campaign_id: page.campaign, ad_group_id: page.adGroup, name: groupName(), asins: [...asins] });
        busy = false;
        if (!r.ok) return show(r.error, "err");
        sentAsins = asins.size;
      }
      return show(`${asins.size} \xFCr\xFCn bu reklam grubuna ba\u011Fland\u0131`, "ok", 'Arama terimleri i\xE7in "Arama terimleri" sekmesini a\xE7\u0131n.');
    }
    const range = rangeOnPage();
    if (!range) return show("Tarih aral\u0131\u011F\u0131 okunamad\u0131", "err", "Sayfa bi\xE7imi de\u011Fi\u015Fmi\u015F olabilir; kay\u0131t yap\u0131lmad\u0131.");
    const k = `st:${page.adGroup}:${range.from}:${range.to}`;
    if (key !== k) {
      key = k;
      terms.clear();
      sentTerms.clear();
      saved = null;
    }
    const total = totalOnPage();
    let bad = 0;
    for (const r of gridRows()) {
      if (r.customerSearchTerm === void 0 || r.clicks === void 0) continue;
      const row = adTermRow({ term: r.customerSearchTerm, target: r.target ?? "", impressions: r.impressions ?? "", clicks: r.clicks, spend: r.spend ?? "", orders: r.orders ?? "", sales: r.sales ?? "" });
      if (row) terms.set(`${row.term}\0${row.target}`, row);
      else bad++;
    }
    const todo = [...terms.keys()].filter((x) => !sentTerms.has(x)).slice(0, 200);
    if (todo.length > 0 && total !== null && !busy) {
      busy = true;
      const r = await send({ type: "adTerms", campaign_id: page.campaign, ad_group_id: page.adGroup, name: groupName(), from: range.from, to: range.to, total, rows: todo.map((x) => terms.get(x)) });
      busy = false;
      if (!r.ok) return show(r.error, "err");
      todo.forEach((x) => sentTerms.add(x));
      saved = r.data.saved;
    }
    const n = saved ?? terms.size;
    const done = total !== null && n >= total;
    show(
      `${n} / ${total ?? "?"} terim okundu`,
      done ? "ok" : "muted",
      `${range.from} \u2013 ${range.to}${done ? " \xB7 tamam" : " \xB7 kalanlar i\xE7in tabloyu a\u015Fa\u011F\u0131 kayd\u0131r\u0131n"}${bad ? ` \xB7 ${bad} sat\u0131r okunamad\u0131` : ""}`
    );
  }
  setInterval(() => void tick(), 1500);
})();
