"use strict";
(() => {
  // src/core/sc-quality.ts
  var LABELS = { item_name: "Ba\u015Fl\u0131k", bullet_point: "Madde", product_description: "A\xE7\u0131klama", generic_keyword: "Arka u\xE7 anahtar kelime", material: "Malzeme", specific_uses_for_product: "Kullan\u0131m alan\u0131" };
  var fieldLabel = (f) => LABELS[f] ?? f.replace(/_/g, " ");
  function scSuggestions(fields2) {
    const by = /* @__PURE__ */ new Map();
    for (const f of fields2) {
      if (!/-value$/.test(f.name)) continue;
      const cur = by.get(f.name) ?? { sug: null, orig: null };
      if (f.disabled) cur.orig ??= f.value;
      else cur.sug ??= f.value;
      by.set(f.name, cur);
    }
    const out = [];
    for (const [name, v] of by) {
      const m = /^(.+?)-(\d+)-value$/.exec(name);
      if (!m || v.sug === null) continue;
      const field = m[1].replace(/-\d+-type$/, "").replace(/-0$/, "");
      const sug = v.sug.trim(), orig = v.orig === null ? null : v.orig.trim();
      if (!sug && !orig) continue;
      out.push({ field, index: Number(m[2]), label: fieldLabel(field), original: orig, suggested: sug, changed: orig === null ? sug !== "" : sug !== orig });
    }
    return out.sort((a, b) => a.field.localeCompare(b.field) || a.index - b.index);
  }

  // extension/src/content-sc.ts
  var send = (m) => chrome.runtime.sendMessage(m).catch(() => void 0);
  function all(root, sel, out = []) {
    root.querySelectorAll(sel).forEach((e) => out.push(e));
    root.querySelectorAll("*").forEach((e) => {
      if (e.shadowRoot) all(e.shadowRoot, sel, out);
    });
    return out;
  }
  function rating() {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      if (!/Liste kaydı kalitesi/i.test(n.textContent ?? "")) continue;
      for (let p = n.parentElement, i = 0; p && i < 5; p = p.parentElement, i++) {
        const b = all(p, "kat-badge")[0];
        const l = b?.getAttribute("label");
        if (l) return l.trim();
      }
    }
    return null;
  }
  function fields() {
    return all(document, 'kat-textarea[name$="-value"], kat-input[name$="-value"], kat-predictive-input[name$="-value"]').map((e) => ({ name: e.getAttribute("name") ?? "", disabled: e.hasAttribute("disabled"), value: String(e.value ?? "") }));
  }
  var params = () => {
    const u = new URL(location.href);
    return { sku: u.searchParams.get("sku"), asin: u.searchParams.get("asin") };
  };
  var last = "";
  function check() {
    const { sku, asin } = params();
    if (!sku) return;
    const r = rating();
    const f = fields();
    const names = new Set(f.filter((x) => x.disabled).map((x) => x.name));
    const panel = f.some((x) => !x.disabled && names.has(x.name));
    const sug = panel ? scSuggestions(f) : null;
    const sig = JSON.stringify([sku, r, sug]);
    if (sig === last || !r && !sug) return;
    last = sig;
    void send({ type: "scQuality", sku, asin, rating: r, ...sug ? { suggestions: sug } : {} });
  }
  var t;
  new MutationObserver(() => {
    clearTimeout(t);
    t = window.setTimeout(check, 1500);
  }).observe(document.documentElement, { subtree: true, childList: true, attributes: true, attributeFilter: ["label", "value", "disabled"] });
  window.setTimeout(check, 3e3);
})();
