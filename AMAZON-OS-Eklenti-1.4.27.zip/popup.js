"use strict";
(() => {
  // extension/src/popup.ts
  var $ = (id) => document.getElementById(id);
  var send = (m) => chrome.runtime.sendMessage(m);
  var msg = (t, cls = "") => {
    $("msg").textContent = t;
    $("msg").className = cls;
  };
  function render(s, forceCfg = false) {
    $("cfg").hidden = s.configured && !forceCfg;
    $("login").hidden = !s.configured || forceCfg || s.email !== null;
    $("out").hidden = !s.configured || forceCfg || s.email === null;
    $("state").textContent = !s.configured ? "Ba\u011Flant\u0131 ayar\u0131 yok" : s.email === null ? `Ba\u011Fl\u0131: ${s.url} \xB7 giri\u015F yap\u0131lmad\u0131` : `${s.email} \xB7 ${s.tenant ?? "i\u015Fletme bulunamad\u0131"}${s.role ? ` (${s.role})` : ""}`;
    if (s.url) $("url").value = s.url;
  }
  async function run(m) {
    msg("\u2026", "muted");
    const r = await send(m);
    if (!r.ok) return msg(r.error, "err");
    msg("");
    render(r.data);
  }
  $("saveCfg").onclick = () => run({ type: "config", url: $("url").value, key: $("key").value });
  $("doLogin").onclick = () => run({ type: "login", email: $("email").value, password: $("pw").value });
  $("doLogout").onclick = () => run({ type: "logout" });
  $("editCfg").onclick = async () => {
    const r = await send({ type: "session" });
    if (r.ok) render(r.data, true);
  };
  void run({ type: "session" });
})();
