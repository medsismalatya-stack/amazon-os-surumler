"use strict";
(() => {
  // src/engine/rational.ts
  var abs = (x) => x < 0n ? -x : x;
  var gcd = (a, b) => {
    a = abs(a);
    b = abs(b);
    while (b !== 0n) [a, b] = [b, a % b];
    return a;
  };
  var toBigInt = (x, label) => {
    if (typeof x === "bigint") return x;
    if (!Number.isSafeInteger(x)) {
      throw new RangeError(`${label} tam say\u0131 olmal\u0131: ${x}`);
    }
    return BigInt(x);
  };
  var Q = class _Q {
    n;
    d;
    constructor(n, d) {
      if (d === 0n) throw new RangeError("Payda s\u0131f\u0131r olamaz");
      if (d < 0n) {
        n = -n;
        d = -d;
      }
      const g = gcd(n, d) || 1n;
      this.n = n / g;
      this.d = d / g;
    }
    static ZERO = new _Q(0n, 1n);
    static ONE = new _Q(1n, 1n);
    /** Tam sayı veya kesir: Q.of(3), Q.of(59700, 101) */
    static of(n, d = 1n) {
      return new _Q(toBigInt(n, "pay"), toBigInt(d, "payda"));
    }
    /** Kuruş cinsinden tutar → TL. Q.kurus(12900) = 129 */
    static kurus(k) {
      return new _Q(toBigInt(k, "kuru\u015F"), 100n);
    }
    /** Ondalık metin → kesin kesir. Q.dec("0.09") = 9/100. Virgül kabul edilmez. */
    static dec(s) {
      const m = /^(-)?(\d+)(?:\.(\d+))?$/.exec(s.trim());
      if (!m) throw new RangeError(`Ge\xE7ersiz ondal\u0131k say\u0131: "${s}"`);
      const [, sign, int, frac = ""] = m;
      const n = BigInt(int + frac) * (sign ? -1n : 1n);
      return new _Q(n, 10n ** BigInt(frac.length));
    }
    add(o) {
      return new _Q(this.n * o.d + o.n * this.d, this.d * o.d);
    }
    sub(o) {
      return new _Q(this.n * o.d - o.n * this.d, this.d * o.d);
    }
    mul(o) {
      return new _Q(this.n * o.n, this.d * o.d);
    }
    div(o) {
      if (o.n === 0n) throw new RangeError("S\u0131f\u0131ra b\xF6lme");
      return new _Q(this.n * o.d, this.d * o.n);
    }
    neg() {
      return new _Q(-this.n, this.d);
    }
    cmp(o) {
      const l = this.n * o.d;
      const r = o.n * this.d;
      return l < r ? -1 : l > r ? 1 : 0;
    }
    eq(o) {
      return this.n === o.n && this.d === o.d;
    }
    isZero() {
      return this.n === 0n;
    }
    sign() {
      return this.n < 0n ? -1 : this.n > 0n ? 1 : 0;
    }
    /** Yukarı yuvarlama (tavan). Sipariş adedi için. */
    ceil() {
      const q = this.n / this.d;
      return this.n % this.d !== 0n && this.n > 0n ? q + 1n : q;
    }
    /** Kesin gösterim: "-571173/10100" */
    toString() {
      return this.d === 1n ? `${this.n}` : `${this.n}/${this.d}`;
    }
    /**
     * YALNIZCA GÖSTERİM içindir. Yarım değerler sıfırdan uzağa yuvarlanır.
     * Hesaplarda kullanılmaz.
     */
    toFixed(digits = 2) {
      const scale = 10n ** BigInt(digits);
      const x = this.n * scale;
      let q = x / this.d;
      const r = abs(x % this.d);
      if (2n * r >= this.d) q += this.n < 0n ? -1n : 1n;
      const neg = q < 0n;
      const s = abs(q).toString().padStart(digits + 1, "0");
      const body = digits === 0 ? s : `${s.slice(0, -digits)}.${s.slice(-digits)}`;
      return (neg ? "-" : "") + body;
    }
  };

  // src/engine/profit.ts
  var STOPAJ_RATE = Q.dec("0.01");
  var AMAZON_FEE_VAT = Q.dec("0.20");
  var VAT_RATES = ["0.01", "0.10", "0.20"];
  var vatRate = (v) => {
    if (v == null || !VAT_RATES.includes(v)) {
      throw new RangeError(`KDV oran\u0131 %1, %10 veya %20 olmal\u0131: ${v}`);
    }
    return Q.dec(v);
  };
  var exVat = (amountIncl, rate) => amountIncl.div(Q.ONE.add(vatRate(rate)));
  function netUnitPurchaseCost(i) {
    const missing = missingKeys(i, [
      "listPriceKurus",
      "listPriceVatIncluded",
      "vatRate",
      "discFirm",
      "discExtra1",
      "discExtra2",
      "discCash"
    ]);
    if (missing.length) return { ok: false, reason: "veri_yetersiz", missing };
    let value = Q.kurus(i.listPriceKurus);
    if (i.listPriceVatIncluded) value = exVat(value, i.vatRate);
    for (const [name, d] of [
      ["discFirm", i.discFirm],
      ["discExtra1", i.discExtra1],
      ["discExtra2", i.discExtra2],
      ["discCash", i.discCash]
    ]) {
      const rate = Q.dec(d);
      if (rate.sign() < 0 || rate.cmp(Q.ONE) >= 0) {
        return { ok: false, reason: "kural_tanimsiz", detail: `${name} 0 ile 1 aras\u0131nda olmal\u0131: ${d}` };
      }
      value = value.mul(Q.ONE.sub(rate));
    }
    return { ok: true, value };
  }
  function missingKeys(obj, keys) {
    return keys.filter((k) => obj[k] === void 0 || obj[k] === null).map(String);
  }
  function unitProfitAtPrice(i) {
    const missing = missingKeys(i, [
      "priceInclKurus",
      "vatRate",
      "amazonFeesBaseKurus",
      "unitPurchaseCost",
      "unitInboundShipping",
      "unitOutboundShipping",
      "unitExtraCost"
    ]);
    if (missing.length) return { ok: false, reason: "veri_yetersiz", missing };
    const salesNet = exVat(Q.kurus(i.priceInclKurus), i.vatRate);
    const stopaj = salesNet.mul(STOPAJ_RATE);
    const fees = Q.kurus(i.amazonFeesBaseKurus);
    const cost = i.unitPurchaseCost.add(i.unitInboundShipping).add(i.unitOutboundShipping).add(i.unitExtraCost);
    return { ok: true, value: { salesNet, stopaj, fees, cost, profit: salesNet.sub(stopaj).sub(fees).sub(cost) } };
  }
  function roi(profit, unitCost) {
    if (unitCost.sign() <= 0) return { ok: false, reason: "kural_tanimsiz", detail: "Birim maliyet 0 iken ROI tan\u0131ms\u0131z" };
    return { ok: true, value: profit.div(unitCost) };
  }
  function purchasePerAsinUnit(netPerItemUnit, unitsPerAsin) {
    if (!Number.isSafeInteger(unitsPerAsin) || unitsPerAsin <= 0) throw new RangeError(`Adet pozitif tam say\u0131 olmal\u0131: ${unitsPerAsin}`);
    return netPerItemUnit.mul(Q.of(unitsPerAsin));
  }

  // src/core/b2b-tema10.ts
  function pctToRate(p) {
    const [i, f = ""] = p.split(".");
    const n = (i.replace(/^0+/, "") || "0").padStart(3, "0");
    const whole = n.slice(0, -2).replace(/^0+/, "") || "0";
    const frac = (n.slice(-2) + f).replace(/0+$/, "");
    return frac ? `${whole}.${frac}` : whole;
  }

  // src/core/b2b-barcode.ts
  var VAT_RATE = { "1": "0.01", "10": "0.10", "20": "0.20" };
  function pctTextToRate(p) {
    const t2 = p.trim().replace(",", ".");
    return /^[0-9]{1,2}(?:\.[0-9]{1,4})?$/.test(t2) ? pctToRate(t2) : null;
  }
  function scanAddFrom(r, cashPct) {
    if (r.status !== "eslesti" || !r.code || r.list_price_kurus === null || r.discounts === null || r.vat_pct === null) return { ok: false, reason: "B2B verisi eksik" };
    const vat = VAT_RATE[r.vat_pct];
    if (!vat) return { ok: false, reason: `KDV tan\u0131nmad\u0131: %${r.vat_pct}` };
    if (r.discounts.length > 3) return { ok: false, reason: `B2B'de ${r.discounts.length} iskonto var (listede firma + 2 ek iskonto alan\u0131)` };
    const d = r.discounts.map(pctTextToRate);
    if (d.some((x) => x === null)) return { ok: false, reason: `\u0130skonto tan\u0131nmad\u0131: ${r.discounts.join(" + ")}` };
    const cash = cashPct ? pctTextToRate(cashPct) : "0";
    if (cash === null) return { ok: false, reason: `Pe\u015Fin iskontosu tan\u0131nmad\u0131: ${cashPct}` };
    const ds = [...d, "0", "0", "0"];
    return {
      ok: true,
      v: {
        code: r.code,
        barcode: r.unit_barcode,
        name: r.title,
        list_price_kurus: r.list_price_kurus,
        list_price_vat_included: false,
        vat_rate: vat,
        disc_firm: ds[0],
        disc_extra1: ds[1],
        disc_extra2: ds[2],
        disc_cash: cash
      }
    };
  }
  function scanOffer(r, supplierName, cashPct) {
    const a = scanAddFrom(r, cashPct);
    if (!a.ok) return a;
    if (r.unit_qty === null) return { ok: false, reason: "ASIN adedi okunamad\u0131" };
    const v = a.v;
    return {
      ok: true,
      units: r.unit_qty,
      offer: {
        id: `b2b:${r.supplier_id}:${v.code}`,
        supplier_id: r.supplier_id,
        supplier_name: supplierName,
        code: v.code,
        barcode: v.barcode,
        name: v.name ?? v.code,
        list_price_kurus: v.list_price_kurus,
        list_price_vat_included: false,
        vat_rate: v.vat_rate,
        disc_firm: v.disc_firm,
        disc_extra1: v.disc_extra1,
        disc_extra2: v.disc_extra2,
        disc_cash: v.disc_cash,
        case_qty: null,
        created_at: r.checked_at,
        updated_at: r.checked_at,
        price_at: null,
        prev_list_price_kurus: null,
        prev_at: null
      }
    };
  }

  // src/engine/buybox.ts
  var UNDERCUT_SHARE_MAX = Q.of(1n, 5n);
  var MIN_BELOW_TOLERANCE = Q.of(5n, 100n);

  // src/core/product-card.ts
  function parseTL(text) {
    const s = text.trim().replace(/\s/g, "");
    if (s === "") return { ok: false, error: "Bo\u015F" };
    const m = /^(\d{1,3}(?:\.\d{3})+|\d+)(?:,(\d{1,2}))?$/.exec(s);
    if (!m) {
      if (/[^\d.,]/.test(s)) return { ok: false, error: "Yaln\u0131z rakam girin (TL, \u20BA ya da harf yazmay\u0131n; \xF6r. 1.250,50)" };
      if (/^\d+\.\d{1,2}$/.test(s)) return { ok: false, error: "Ondal\u0131k i\xE7in virg\xFCl kullan\u0131n (\xF6r. 32,50)" };
      if (/,\d{3,}$/.test(s)) return { ok: false, error: "En \xE7ok 2 ondal\u0131k (kuru\u015F) girilebilir" };
      return { ok: false, error: "Ge\xE7ersiz tutar" };
    }
    const int = m[1].replace(/\./g, "");
    const frac = (m[2] ?? "").padEnd(2, "0");
    return { ok: true, value: BigInt(int) * 100n + BigInt(frac) };
  }
  function parsePercent(text) {
    const s = text.trim().replace(/^%/, "").replace(/\s/g, "");
    if (s === "") return { ok: false, error: "Bo\u015F" };
    const m = /^(\d{1,2})(?:,(\d+))?$/.exec(s);
    if (!m) return { ok: false, error: /^\d+\.\d+$/.test(s) ? "Ondal\u0131k i\xE7in virg\xFCl kullan\u0131n" : "0 ile 100 aras\u0131nda y\xFCzde girin" };
    const digits = (m[1].padStart(2, "0") + (m[2] ?? "")).replace(/0+$/, "");
    return { ok: true, value: digits === "" ? "0" : `0.${digits}` };
  }
  function rateToPercentText(rate) {
    const m = /^0(?:\.(\d+))?$/.exec(rate);
    if (!m) throw new RangeError(`Ge\xE7ersiz oran: ${rate}`);
    const d = (m[1] ?? "").padEnd(2, "0");
    const int = String(Number.parseInt(d.slice(0, 2), 10));
    const frac = d.slice(2).replace(/0+$/, "");
    return frac ? `${int},${frac}` : int;
  }
  function formatTL(q, digits = 2) {
    const s = q.toFixed(digits);
    const neg = s.startsWith("-");
    const [int, frac] = s.replace("-", "").split(".");
    const grouped = int.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    return (neg ? "-" : "") + grouped + (frac ? `,${frac}` : "");
  }
  var COST_PREFILL = { inbound: "0", outbound: "2", extra: "0" };

  // src/core/opportunity.ts
  var thresholdOf = (setting) => setting === null || setting === void 0 ? null : Q.dec(setting);
  var emptyItemForm = () => ({
    supplierId: "",
    name: "",
    barcode: "",
    listPrice: "",
    listVatIncluded: "H",
    vatRate: "",
    discFirm: "0",
    discExtra1: "0",
    discExtra2: "0",
    discCash: "0",
    caseQty: ""
  });
  function evaluateItemForm(f) {
    const errors = {};
    if (!f.supplierId) errors.supplierId = "Firma se\xE7in";
    const name = f.name.trim().replace(/\s+/g, " ");
    const list = parseTL(f.listPrice);
    if (!list.ok) errors.listPrice = list.error;
    else if (list.value === 0n) errors.listPrice = "0'dan b\xFCy\xFCk olmal\u0131";
    if (!f.vatRate) errors.vatRate = "Se\xE7in";
    const disc = {};
    for (const key of ["discFirm", "discExtra1", "discExtra2", "discCash"]) {
      const r = parsePercent(f[key]);
      if (r.ok) disc[key] = r.value;
      else errors[key] = r.error === "Bo\u015F" ? "Zorunlu (yoksa 0)" : r.error;
    }
    const cq = (f.caseQty ?? "").trim();
    let unitKurus = list.ok ? list.value : 0n;
    if (cq !== "") {
      if (!/^\d{1,6}$/.test(cq) || Number(cq) < 1 || Number(cq) > 1e5) errors.caseQty = "Pozitif tam say\u0131";
      else if (list.ok && Number(cq) > 1) {
        const c = BigInt(cq);
        if (list.value % c !== 0n) errors.caseQty = `Koli fiyat\u0131 ${cq}'e tam kuru\u015F b\xF6l\xFCnm\xFCyor: adet fiyat\u0131n\u0131 girin`;
        else unitKurus = list.value / c;
      }
    }
    if (Object.keys(errors).length || !list.ok || !f.vatRate) return { errors, payload: null, net: null };
    const net = netUnitPurchaseCost({
      listPriceKurus: unitKurus,
      listPriceVatIncluded: f.listVatIncluded === "E",
      vatRate: f.vatRate,
      discFirm: disc.discFirm,
      discExtra1: disc.discExtra1,
      discExtra2: disc.discExtra2,
      discCash: disc.discCash
    });
    return {
      errors,
      net: net.ok ? net.value : null,
      payload: {
        supplier_id: f.supplierId,
        name: name === "" ? null : name,
        barcode: f.barcode.trim() === "" ? null : f.barcode.trim(),
        list_price_kurus: unitKurus.toString(),
        // 0097: girilen koli içi saklanır (1 / boş → yok)
        entry_case_qty: cq !== "" && Number(cq) > 1 ? Number(cq) : null,
        list_price_vat_included: f.listVatIncluded === "E",
        vat_rate: f.vatRate,
        disc_firm: disc.discFirm,
        disc_extra1: disc.discExtra1,
        disc_extra2: disc.discExtra2,
        disc_cash: disc.discCash
      }
    };
  }
  var emptyAsinForm = () => ({ asin: "", units: "1", inbound: "", outbound: "", extra: "" });
  function evaluateAsinForm(f) {
    const errors = {};
    const asin = f.asin.trim().toUpperCase();
    if (!/^[A-Z0-9]{10}$/.test(asin)) errors.asin = "10 karakterli ASIN";
    const units = /^\d{1,4}$/.test(f.units.trim()) ? Number(f.units.trim()) : NaN;
    if (!(units > 0)) errors.units = "Pozitif tam say\u0131";
    const cost = (key) => {
      if (f[key].trim() === "") return null;
      const r = parseTL(f[key]);
      if (!r.ok) {
        errors[key] = r.error;
        return null;
      }
      return r.value.toString();
    };
    const inbound = cost("inbound");
    const outbound = cost("outbound");
    const extra = cost("extra");
    if (Object.keys(errors).length) return { errors, payload: null };
    return { errors, payload: { asin, units, inbound_kurus: inbound, outbound_kurus: outbound, extra_kurus: extra } };
  }
  var emptyQuickForm = (keep) => ({
    ...emptyItemForm(),
    ...emptyAsinForm(),
    ...COST_PREFILL,
    ...keep ?? {}
  });
  function evaluateQuickForm(f) {
    const i = evaluateItemForm(f);
    const a = evaluateAsinForm(f);
    const errors = { ...i.errors, ...a.errors };
    const code = (f.code ?? "").trim();
    if (code.length > 64) errors.code = "Firma kodu en \xE7ok 64 karakter";
    return { errors, item: errors.code ? null : i.payload, asin: a.payload, net: i.net, code: code === "" ? null : code };
  }
  function scanPurchasePreview(ev, bbKurus, feesKurus, threshold) {
    const none = { profit: null, roi: null, cost: null };
    if (!ev.item || !ev.asin || !ev.net) return { status: "veri_yetersiz", missing: ["alis_bilgisi"], ...none };
    if (bbKurus === null) return { status: "veri_yetersiz", missing: ["buybox_fiyati"], ...none };
    if (feesKurus === null) return { status: "veri_yetersiz", missing: ["ucret_tahmini"], ...none };
    const a = ev.asin;
    const miss = [a.inbound_kurus === null && "gelen_kargo", a.outbound_kurus === null && "giden_kargo", a.extra_kurus === null && "ek_maliyet"].filter(
      (x) => !!x
    );
    if (miss.length) return { status: "veri_yetersiz", missing: miss, ...none };
    const p = unitProfitAtPrice({
      priceInclKurus: BigInt(bbKurus),
      vatRate: ev.item.vat_rate,
      amazonFeesBaseKurus: BigInt(feesKurus),
      unitPurchaseCost: purchasePerAsinUnit(ev.net, a.units),
      unitInboundShipping: Q.kurus(BigInt(a.inbound_kurus)),
      unitOutboundShipping: Q.kurus(BigInt(a.outbound_kurus)),
      unitExtraCost: Q.kurus(BigInt(a.extra_kurus))
    });
    if (!p.ok) return p.reason === "veri_yetersiz" ? { status: "veri_yetersiz", missing: p.missing, ...none } : { status: "kural_tanimsiz", missing: [], ...none };
    const r = roi(p.value.profit, p.value.cost);
    if (!r.ok) return { status: "kural_tanimsiz", missing: [], profit: p.value.profit, roi: null, cost: p.value.cost };
    const base = { missing: [], profit: p.value.profit, roi: r.value, cost: p.value.cost };
    if (threshold === null) return { status: "esik_yok", ...base };
    if (p.value.profit.sign() <= 0) return { status: "karsiz", ...base };
    return { status: r.value.cmp(threshold) >= 0 ? "karli" : "karsiz", ...base };
  }
  function quickFormFromScan(r, vatRate2, inboundKurus, outboundKurus, keep) {
    const t2 = (s) => `${BigInt(s) / 100n},${String(BigInt(s) % 100n).padStart(2, "0")}`;
    const base = keep ? { ...emptyQuickForm({ supplierId: keep.supplierId, vatRate: vatRate2, listVatIncluded: keep.listVatIncluded }), discFirm: keep.discFirm, discExtra1: keep.discExtra1, discExtra2: keep.discExtra2, discCash: keep.discCash } : emptyQuickForm({ supplierId: "", vatRate: vatRate2, listVatIncluded: "H" });
    return { ...base, name: r.title ?? "", asin: r.asin, inbound: t2(inboundKurus), outbound: t2(outboundKurus), extra: "0" };
  }

  // src/core/price-list.ts
  var kurusText = (k) => `${k / 100n},${String(k % 100n).padStart(2, "0")}`;
  function fillFromOffer(f, o) {
    const k = BigInt(o.list_price_kurus);
    return {
      ...f,
      supplierId: o.supplier_id,
      name: f.name.trim() === "" ? o.name : f.name,
      barcode: f.barcode.trim() === "" ? o.barcode ?? "" : f.barcode,
      code: (f.code ?? "").trim() === "" ? o.code ?? "" : f.code,
      listPrice: kurusText(k),
      caseQty: o.case_qty != null && o.case_qty > 1 ? String(o.case_qty) : "",
      listVatIncluded: o.list_price_vat_included ? "E" : "H",
      vatRate: o.vat_rate,
      discFirm: rateToPercentText(o.disc_firm),
      discExtra1: rateToPercentText(o.disc_extra1),
      discExtra2: rateToPercentText(o.disc_extra2),
      discCash: rateToPercentText(o.disc_cash)
    };
  }

  // src/core/b2b-amazon.ts
  function b2bPageBarcodes(text) {
    const i = text.search(/BARKOD\s+B[İI]R[İI]M\s+M[İI]KTAR/i);
    if (i < 0) return [];
    const out = [];
    for (const line of text.slice(i).split("\n").slice(1)) {
      const m = /^\s*(\d{8,14})\s/.exec(line);
      if (!m) break;
      if (!out.includes(m[1])) out.push(m[1]);
    }
    return out.slice(0, 10);
  }
  function b2bAmazonPreview(h, o) {
    if (!h.rec || h.rec.status !== "eslesti") return { ok: false, reason: h.rec?.message ?? (h.rec ? `B2B: ${h.rec.status}` : "B2B e\u015Fle\u015Fmesi yok") };
    const so = scanOffer(h.rec, o.supplierName, o.cash);
    if (!so.ok) return { ok: false, reason: so.reason };
    const base = quickFormFromScan({ asin: h.asin, title: h.title }, so.offer.vat_rate, o.inboundKurus, o.outboundKurus);
    const form = { ...fillFromOffer(base, so.offer), units: String(so.units) };
    const ev = evaluateQuickForm(form);
    return { ok: true, units: so.units, net: ev.net, offer: so.offer, form, preview: scanPurchasePreview(ev, h.bbKurus, h.feesKurus, thresholdOf(o.minRoi)) };
  }

  // extension/src/content-b2b.ts
  var send = (m) => chrome.runtime.sendMessage(m).catch((e) => ({ ok: false, error: e.message }));
  var tl = (k) => k === null ? "\u2014" : `${formatTL(Q.kurus(BigInt(k)))} TL`;
  var host = document.createElement("div");
  host.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:2147483647;";
  var root = host.attachShadow({ mode: "closed" });
  root.innerHTML = `<style>
  .box{font:13px/1.45 system-ui,Segoe UI,Arial,sans-serif;background:#fff;color:#111;border:1px solid #c9ced6;border-radius:10px;box-shadow:0 6px 20px rgba(0,0,0,.2);padding:10px 12px;width:380px;max-height:75vh;overflow:auto}
  .head{display:flex;justify-content:space-between;align-items:center;font-weight:600}
  .x{border:0;background:none;font-size:16px;cursor:pointer;color:#666}
  .ok{color:#0a7d32}.neg{color:#b3261e}.warn{color:#9a5b00}.muted{color:#666;font-size:12px}
  .hit{border-top:1px solid #eee;padding:6px 0}
  button.b{padding:4px 10px;border:1px solid #0f6e63;background:#0f6e63;color:#fff;border-radius:6px;cursor:pointer;font:inherit}
  button.l{border:0;background:none;color:#1f5fa8;cursor:pointer;padding:0;font:inherit;text-decoration:underline}
  button:disabled{opacity:.5;cursor:default}
  input{width:80px;box-sizing:border-box;padding:3px 5px;border:1px solid #c9ced6;border-radius:6px;font:inherit}
  a{color:#1f5fa8}
</style><div class="box"><div class="head"><span>AMAZON OS \xB7 B2B \u2192 Amazon</span><button class="x" title="Kapat">\u2715</button></div><div id="body"></div></div>`;
  var $body = root.getElementById("body");
  root.querySelector(".x").addEventListener("click", () => host.remove());
  var el = (tag, props = {}, text) => {
    const e = document.createElement(tag);
    Object.assign(e, props);
    if (text !== void 0) e.textContent = text;
    return e;
  };
  var open = () => {
    if (!host.isConnected) document.documentElement.appendChild(host);
  };
  var site;
  async function siteInfo() {
    if (site !== void 0) return site;
    const r = await send({ type: "b2bSite", host: location.host });
    if (!r.ok) throw new Error(r.error);
    site = r.data;
    return site;
  }
  function askShip(s, then) {
    $body.replaceChildren();
    $body.append(el("div", { className: "warn" }, `${s.name}: k\xE2r i\xE7in birim ba\u015F\u0131na kargo girin (bir kez; sonra de\u011Fi\u015Ftirilebilir).`));
    const inb = el("input", { placeholder: "0,00", value: s.inbound !== null ? formatTL(Q.kurus(BigInt(s.inbound))) : "" });
    const out = el("input", { placeholder: "2,00", value: s.outbound !== null ? formatTL(Q.kurus(BigInt(s.outbound))) : "" });
    const err = el("div", { className: "neg" });
    const save = el("button", { className: "b", type: "button" }, "Kaydet");
    save.addEventListener("click", async () => {
      const a = parseTL(inb.value);
      const b = parseTL(out.value);
      if (!a.ok || !b.ok) {
        err.textContent = `${!a.ok ? `Gelen: ${a.error}` : ""} ${!b.ok ? `Giden: ${b.error}` : ""}`;
        return;
      }
      const r = await send({ type: "b2bShip", supplier_id: s.supplier_id, inbound: a.value.toString(), outbound: b.value.toString() });
      if (!r.ok) {
        err.textContent = r.error;
        return;
      }
      s.inbound = a.value.toString();
      s.outbound = b.value.toString();
      then();
    });
    const row = (label, i) => {
      const d = el("div");
      d.append(`${label} `, i, " TL");
      return d;
    };
    $body.append(row("Gelen kargo (tedarik\xE7iden, birim)", inb), row("Giden kargo (Amazon depoya, birim)", out), save, err);
  }
  var lastFetch = 0;
  function barcodesFromDoc(doc) {
    for (const t2 of doc.querySelectorAll("table")) {
      const head = (t2.querySelector("tr")?.textContent ?? "").toUpperCase();
      if (!/BARKOD/.test(head)) continue;
      const out = [...t2.querySelectorAll("tr")].map((tr) => (tr.firstElementChild?.textContent ?? "").trim()).filter((x) => /^\d{8,14}$/.test(x));
      if (out.length) return [...new Set(out)].slice(0, 10);
    }
    return b2bPageBarcodes(doc.body.innerText ?? "");
  }
  async function barcodesOf(url) {
    if (!url || new URL(url, location.href).pathname === location.pathname) return barcodesFromDoc(document);
    const wait = lastFetch + 1100 - Date.now();
    if (wait > 0) await new Promise((r) => setTimeout(r, wait));
    lastFetch = Date.now();
    const res = await fetch(new URL(url, location.href).href, { credentials: "same-origin" });
    if (!res.ok) throw new Error(`B2B \xFCr\xFCn sayfas\u0131 a\xE7\u0131lamad\u0131 (durum ${res.status})`);
    return barcodesFromDoc(new DOMParser().parseFromString(await res.text(), "text/html"));
  }
  var busy = false;
  async function lookup(name, url) {
    if (busy) return;
    open();
    $body.replaceChildren(el("div", { className: "muted" }, "Ba\u011Flan\u0131yor\u2026"));
    let s;
    try {
      s = await siteInfo();
    } catch (e) {
      $body.replaceChildren(el("div", { className: "neg" }, `${e.message} \u2014 eklenti simgesinden AMAZON OS hesab\u0131yla giri\u015F yap\u0131n.`));
      return;
    }
    if (!s) {
      $body.replaceChildren(el("div", { className: "neg" }, "Bu B2B sitesi programda kay\u0131tl\u0131 de\u011Fil (Tedarik\xE7iler \u203A B2B hesab\u0131)."));
      return;
    }
    if (s.inbound === null || s.outbound === null) return askShip(s, () => void lookup(name, url));
    busy = true;
    const t0 = Date.now();
    const status = el("div", { className: "muted" });
    $body.replaceChildren(el("div", {}, name), status);
    const tick = (what) => {
      status.textContent = `${what} \xB7 ${Math.round((Date.now() - t0) / 1e3)} sn`;
    };
    let step = "barkod okunuyor";
    const iv = setInterval(() => tick(step), 1e3);
    tick(step);
    try {
      const bcs = await barcodesOf(url);
      if (!bcs.length) {
        status.className = "neg";
        status.textContent = "\xDCr\xFCn sayfas\u0131nda barkod tablosu bulunamad\u0131.";
        return;
      }
      step = `Amazon'da aran\u0131yor (${bcs.length} barkod)`;
      tick(step);
      const r = await send({ type: "b2bAmazon", supplier_id: s.supplier_id, barcodes: bcs });
      if (!r.ok) {
        status.className = "neg";
        status.textContent = r.error;
        return;
      }
      if (!r.data.ok) {
        status.className = "neg";
        status.textContent = r.data.message;
        return;
      }
      const sec = Math.round((Date.now() - t0) / 1e3);
      status.className = "muted";
      status.textContent = `Barkod ${bcs.join(", ")} \xB7 ${sec} sn${r.data.b2bNote ? ` \xB7 ${r.data.b2bNote}` : ""}`;
      if (!r.data.hits.length) {
        $body.append(el("div", { className: "warn" }, "Amazon'da bu barkodla \xFCr\xFCn yok."));
        return;
      }
      for (const h of r.data.hits) $body.append(hitView(s, h));
      const ch = el("button", { className: "l", type: "button" }, "kargoyu de\u011Fi\u015Ftir");
      ch.addEventListener("click", () => askShip(s, () => void lookup(name, url)));
      $body.append(el("div", { className: "muted" }, `Kargo: gelen ${tl(s.inbound)} \xB7 giden ${tl(s.outbound)} \xB7 `), ch);
    } catch (e) {
      status.className = "neg";
      status.textContent = e.message;
    } finally {
      clearInterval(iv);
      busy = false;
    }
  }
  function hitView(s, h) {
    const d = el("div", { className: "hit" });
    const a = el("a", { href: `https://www.amazon.com.tr/dp/${h.asin}`, target: "_blank", rel: "noreferrer" }, h.asin);
    d.append(a, ` \xB7 ${h.title ?? "(ad yok)"}`);
    d.append(el("div", { className: "muted" }, `${h.brand ?? "\u2014"}${h.bsr !== null ? ` \xB7 BSR ${h.bsr.toLocaleString("tr-TR")}${h.bsrGroup ? ` (${h.bsrGroup})` : ""}` : " \xB7 BSR yok"}`));
    const bb = h.offersError ? `Buy Box okunamad\u0131: ${h.offersError}` : h.bbKurus === null ? `Buy Box yok${h.situation ? ` (${h.situation})` : ""}` : `Buy Box ${tl(h.bbKurus)}${h.feesKurus ? ` \xB7 Amazon \xFCcreti ${tl(h.feesKurus)}` : h.feesError ? ` \xB7 \xFCcret: ${h.feesError}` : ""}`;
    d.append(el("div", {}, bb));
    const pv = b2bAmazonPreview(h, { supplierName: s.name, cash: s.cash, inboundKurus: s.inbound, outboundKurus: s.outbound, minRoi: s.minRoi });
    if (!pv.ok) {
      d.append(el("div", { className: "warn" }, `B2B: ${pv.reason}`));
      return d;
    }
    d.append(el("div", { className: "muted" }, `Al\u0131\u015F ${pv.net ? `${formatTL(pv.net)} TL` : "\u2014"} (net, KDV hari\xE7)${pv.units > 1 ? ` \xB7 ASIN'de ${pv.units} adet` : ""}${s.cash ? ` \xB7 pe\u015Fin %${s.cash} dahil` : ""}`));
    const p = pv.preview;
    if (p.profit && p.roi) {
      const pct = p.roi.mul(Q.of(100)).toFixed(1).replace(".", ",");
      d.append(el("div", { className: p.profit.sign() > 0 ? "ok" : "neg" }, `K\xE2r ${formatTL(p.profit)} TL \xB7 ROI %${pct} \xB7 ${p.status === "karli" ? "K\xE2rl\u0131" : p.status === "karsiz" ? "K\xE2rs\u0131z" : p.status === "esik_yok" ? "ROI e\u015Fi\u011Fi girilmemi\u015F" : p.status}`));
    } else d.append(el("div", { className: "warn" }, `K\xE2r hesaplanamad\u0131: eksik ${p.missing.join(", ") || p.status}`));
    const add = el("button", { className: "b", type: "button" }, "\u2795 F\u0131rsat Havuzu'na ekle");
    const res = el("div");
    add.addEventListener("click", async () => {
      add.disabled = true;
      res.className = "muted";
      res.textContent = "ekleniyor\u2026";
      const r = await send({ type: "b2bPool", supplier_id: s.supplier_id, supplierName: s.name, cash: s.cash, rec: h.rec, base: pv.form });
      if (!r.ok) {
        res.className = "neg";
        res.textContent = r.error;
        add.disabled = false;
        return;
      }
      if (!r.data.ok) {
        res.className = "neg";
        res.textContent = r.data.reason;
        add.disabled = false;
        return;
      }
      res.className = "ok";
      res.textContent = `F\u0131rsat Havuzu'na eklendi${r.data.newRow ? " \xB7 fiyat listesine yeni sat\u0131r a\xE7\u0131ld\u0131" : ""}${r.data.note ? ` \xB7 ${r.data.note}` : ""}. Saatlik kontrolde K\xE2rl\u0131 / K\xE2rs\u0131z'a yerle\u015Fir.`;
    });
    d.append(add, res);
    return d;
  }
  var BTN = "aos-b2b-amz";
  function mkBtn(name, url) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = BTN;
    b.textContent = "\u{1F50E} Amazon";
    b.title = "AMAZON OS: barkodla Amazon'da ara, Buy Box ve k\xE2r\u0131 g\xF6ster";
    b.style.cssText = "margin:4px 0;padding:2px 8px;border:1px solid #0f6e63;background:#fff;color:#0f6e63;border-radius:6px;cursor:pointer;font:12px system-ui,Arial";
    b.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      void lookup(name, url);
    });
    return b;
  }
  function paint() {
    for (const card of document.querySelectorAll(".product-item-container")) {
      if (card.querySelector(`.${BTN}`)) continue;
      const a = card.querySelector('a[href*="/urun/"]');
      if (!a) continue;
      const name = (card.querySelector("h4, .caption a, .product-name")?.textContent ?? card.innerText.split("\n")[0] ?? "").trim();
      card.appendChild(mkBtn(name, a.href));
    }
    if (/^\/urun\//.test(location.pathname) && !document.querySelector(`.${BTN}[data-main]`)) {
      const h = document.querySelector("h1, .product-name, .title-product");
      if (h) {
        const b = mkBtn(h.textContent?.trim() ?? "", null);
        b.dataset.main = "1";
        h.insertAdjacentElement("afterend", b);
      }
    }
  }
  var t;
  new MutationObserver(() => {
    clearTimeout(t);
    t = setTimeout(paint, 500);
  }).observe(document.documentElement, { childList: true, subtree: true });
  paint();
})();
