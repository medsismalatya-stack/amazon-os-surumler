"use strict";
(() => {
  // src/engine/rational.ts
  var abs = (x) => x < 0n ? -x : x;
  var gcd = (a, b) => {
    a = abs(a);
    b = abs(b);
    while (b !== 0n) [a, b] = [b, a % b];
    return a;
  };
  var toBigInt = (x, label) => {
    if (typeof x === "bigint") return x;
    if (!Number.isSafeInteger(x)) {
      throw new RangeError(`${label} tam say\u0131 olmal\u0131: ${x}`);
    }
    return BigInt(x);
  };
  var Q = class _Q {
    n;
    d;
    constructor(n, d) {
      if (d === 0n) throw new RangeError("Payda s\u0131f\u0131r olamaz");
      if (d < 0n) {
        n = -n;
        d = -d;
      }
      const g = gcd(n, d) || 1n;
      this.n = n / g;
      this.d = d / g;
    }
    static ZERO = new _Q(0n, 1n);
    static ONE = new _Q(1n, 1n);
    /** Tam sayı veya kesir: Q.of(3), Q.of(59700, 101) */
    static of(n, d = 1n) {
      return new _Q(toBigInt(n, "pay"), toBigInt(d, "payda"));
    }
    /** Kuruş cinsinden tutar → TL. Q.kurus(12900) = 129 */
    static kurus(k) {
      return new _Q(toBigInt(k, "kuru\u015F"), 100n);
    }
    /** Ondalık metin → kesin kesir. Q.dec("0.09") = 9/100. Virgül kabul edilmez. */
    static dec(s) {
      const m = /^(-)?(\d+)(?:\.(\d+))?$/.exec(s.trim());
      if (!m) throw new RangeError(`Ge\xE7ersiz ondal\u0131k say\u0131: "${s}"`);
      const [, sign, int, frac = ""] = m;
      const n = BigInt(int + frac) * (sign ? -1n : 1n);
      return new _Q(n, 10n ** BigInt(frac.length));
    }
    add(o) {
      return new _Q(this.n * o.d + o.n * this.d, this.d * o.d);
    }
    sub(o) {
      return new _Q(this.n * o.d - o.n * this.d, this.d * o.d);
    }
    mul(o) {
      return new _Q(this.n * o.n, this.d * o.d);
    }
    div(o) {
      if (o.n === 0n) throw new RangeError("S\u0131f\u0131ra b\xF6lme");
      return new _Q(this.n * o.d, this.d * o.n);
    }
    neg() {
      return new _Q(-this.n, this.d);
    }
    cmp(o) {
      const l = this.n * o.d;
      const r = o.n * this.d;
      return l < r ? -1 : l > r ? 1 : 0;
    }
    eq(o) {
      return this.n === o.n && this.d === o.d;
    }
    isZero() {
      return this.n === 0n;
    }
    sign() {
      return this.n < 0n ? -1 : this.n > 0n ? 1 : 0;
    }
    /** Yukarı yuvarlama (tavan). Sipariş adedi için. */
    ceil() {
      const q = this.n / this.d;
      return this.n % this.d !== 0n && this.n > 0n ? q + 1n : q;
    }
    /** Kesin gösterim: "-571173/10100" */
    toString() {
      return this.d === 1n ? `${this.n}` : `${this.n}/${this.d}`;
    }
    /**
     * YALNIZCA GÖSTERİM içindir. Yarım değerler sıfırdan uzağa yuvarlanır.
     * Hesaplarda kullanılmaz.
     */
    toFixed(digits = 2) {
      const scale = 10n ** BigInt(digits);
      const x = this.n * scale;
      let q = x / this.d;
      const r = abs(x % this.d);
      if (2n * r >= this.d) q += this.n < 0n ? -1n : 1n;
      const neg = q < 0n;
      const s = abs(q).toString().padStart(digits + 1, "0");
      const body = digits === 0 ? s : `${s.slice(0, -digits)}.${s.slice(-digits)}`;
      return (neg ? "-" : "") + body;
    }
  };

  // src/engine/profit.ts
  var STOPAJ_RATE = Q.dec("0.01");
  var AMAZON_FEE_VAT = Q.dec("0.20");

  // src/engine/buybox.ts
  var UNDERCUT_SHARE_MAX = Q.of(1n, 5n);
  var MIN_BELOW_TOLERANCE = Q.of(5n, 100n);

  // src/core/opportunity.ts
  var STATUS_LABEL = {
    karli: "K\xE2rl\u0131",
    karsiz: "K\xE2rs\u0131z",
    veri_yetersiz: "Veri yetersiz",
    kural_tanimsiz: "Kural tan\u0131ms\u0131z",
    esik_yok: "E\u015Fik girilmedi"
  };

  // src/core/amazon-extension.ts
  function asinFromUrl(url) {
    let u;
    try {
      u = new URL(url);
    } catch {
      return null;
    }
    if (!/(^|\.)amazon\.com\.tr$/.test(u.hostname)) return null;
    const m = /\/(?:dp|gp\/product|gp\/aw\/d|d)\/([A-Z0-9]{10})(?:[/?#]|$)/i.exec(u.pathname + "/");
    return m ? m[1].toUpperCase() : null;
  }
  function statusView(s) {
    if (s.selling) return { text: "Bu \xFCr\xFCn\xFC zaten sat\u0131yorsun", tone: "ok", canAdd: false };
    if (s.pool_status !== null) {
      const st = s.pool_status === "yeni" ? "s\u0131n\u0131flama bekliyor" : STATUS_LABEL[s.pool_status];
      return { text: `F\u0131rsat Havuzunda \xB7 ${s.pool_elim ? "elendi" : st}`, tone: "info", canAdd: false };
    }
    if (s.pending) return { text: `F\u0131rsat Havuzunda \xB7 Al\u0131\u015F fiyat\u0131 bekleniyor${s.pending_elim ? " (elendi)" : ""}`, tone: "info", canAdd: false };
    return { text: "Bizde yok", tone: "warn", canAdd: true };
  }
  var ADD_RESULT_TEXT = {
    eklendi: "F\u0131rsat Havuzuna eklendi (Al\u0131\u015F fiyat\u0131 bekleniyor). Buy Box ve Amazon \xFCcreti bir saat i\xE7inde gelir.",
    satiyoruz: "Eklenmedi: bu \xFCr\xFCn\xFC zaten sat\u0131yorsun.",
    havuzda: "Eklenmedi: \xFCr\xFCn zaten F\u0131rsat Havuzunda.",
    bekliyor: "Eklenmedi: \xFCr\xFCn zaten Al\u0131\u015F fiyat\u0131 bekleniyor listesinde."
  };

  // extension/src/content.ts
  var send = (m) => chrome.runtime.sendMessage(m);
  var host = document.createElement("div");
  host.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:2147483647;";
  var root = host.attachShadow({ mode: "closed" });
  root.innerHTML = `<style>
  .box{font:13px/1.4 system-ui,Segoe UI,Arial,sans-serif;background:#fff;color:#111;border:1px solid #c9ced6;border-radius:8px;
       box-shadow:0 4px 16px rgba(0,0,0,.18);padding:10px 12px;width:290px}
  .head{display:flex;justify-content:space-between;align-items:center;font-weight:600;margin-bottom:4px}
  .x{border:0;background:none;font-size:16px;cursor:pointer;color:#666}
  .ok{color:#0a7d32}.info{color:#1f5fa8}.warn{color:#9a5b00}.err{color:#b3261e}
  .add{margin-top:8px}.add button{margin-right:6px;padding:3px 8px;border:1px solid #1f5fa8;background:#eef4fc;color:#1f5fa8;border-radius:5px;cursor:pointer}
  .add button:disabled{opacity:.5;cursor:default}.muted{color:#666;font-size:12px}
</style><div class="box"><div class="head"><span>AMAZON OS \xB7 <span id="asin"></span></span><button class="x" title="Kapat">\xD7</button></div>
<div id="msg"></div><div id="add" class="add" hidden><div class="muted">F\u0131rsat Havuzuna ekle \u2014 \xFCr\xFCn\xFCn KDV oran\u0131:</div>
<button data-vat="0.20">%20</button><button data-vat="0.10">%10</button><button data-vat="0.01">%1</button></div></div>`;
  var $ = (id) => root.getElementById(id);
  var current = null;
  var closed = null;
  function show(text, cls) {
    const m = $("msg");
    m.textContent = text;
    m.className = cls;
  }
  async function load(asin) {
    $("asin").textContent = asin;
    $("add").hidden = true;
    show("kontrol ediliyor\u2026", "muted");
    const r = await send({ type: "status", asin }).catch((e) => ({ ok: false, error: e.message }));
    if (asin !== current) return;
    if (!r.ok) return show(r.error, "err");
    const v = statusView(r.data);
    show(v.text, v.tone);
    $("add").hidden = !v.canAdd;
  }
  for (const b of Array.from(root.querySelectorAll("button[data-vat]"))) {
    b.addEventListener("click", async () => {
      const asin = current;
      if (!asin) return;
      const btns = Array.from(root.querySelectorAll("button[data-vat]"));
      btns.forEach((x) => x.disabled = true);
      const t0 = Date.now();
      show("ekleniyor\u2026", "muted");
      const title = document.getElementById("productTitle")?.textContent ?? null;
      const r = await send({ type: "add", asin, title, vat: b.dataset.vat }).catch((e) => ({ ok: false, error: e.message }));
      btns.forEach((x) => x.disabled = false);
      if (asin !== current) return;
      if (!r.ok) return show(`${r.error} \xB7 ${Math.round((Date.now() - t0) / 1e3)} sn`, "err");
      const res = r.data;
      show(ADD_RESULT_TEXT[res], res === "eklendi" ? "ok" : "info");
      $("add").hidden = true;
    });
  }
  root.querySelector(".x").addEventListener("click", () => {
    closed = current;
    host.remove();
  });
  function tick() {
    const asin = asinFromUrl(location.href);
    if (asin === current) return;
    current = asin;
    if (!asin || asin === closed) {
      host.remove();
      return;
    }
    if (!host.isConnected) document.documentElement.appendChild(host);
    void load(asin);
  }
  tick();
  setInterval(tick, 1e3);
})();
