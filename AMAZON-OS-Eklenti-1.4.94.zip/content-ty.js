"use strict";
(() => {
  // src/engine/rational.ts
  var abs = (x) => x < 0n ? -x : x;
  var gcd = (a, b) => {
    a = abs(a);
    b = abs(b);
    while (b !== 0n) [a, b] = [b, a % b];
    return a;
  };
  var toBigInt = (x, label) => {
    if (typeof x === "bigint") return x;
    if (!Number.isSafeInteger(x)) {
      throw new RangeError(`${label} tam say\u0131 olmal\u0131: ${x}`);
    }
    return BigInt(x);
  };
  var Q = class _Q {
    n;
    d;
    constructor(n, d) {
      if (d === 0n) throw new RangeError("Payda s\u0131f\u0131r olamaz");
      if (d < 0n) {
        n = -n;
        d = -d;
      }
      const g = gcd(n, d) || 1n;
      this.n = n / g;
      this.d = d / g;
    }
    static ZERO = new _Q(0n, 1n);
    static ONE = new _Q(1n, 1n);
    /** Tam sayı veya kesir: Q.of(3), Q.of(59700, 101) */
    static of(n, d = 1n) {
      return new _Q(toBigInt(n, "pay"), toBigInt(d, "payda"));
    }
    /** Kuruş cinsinden tutar → TL. Q.kurus(12900) = 129 */
    static kurus(k) {
      return new _Q(toBigInt(k, "kuru\u015F"), 100n);
    }
    /** Ondalık metin → kesin kesir. Q.dec("0.09") = 9/100. Virgül kabul edilmez. */
    static dec(s) {
      const m = /^(-)?(\d+)(?:\.(\d+))?$/.exec(s.trim());
      if (!m) throw new RangeError(`Ge\xE7ersiz ondal\u0131k say\u0131: "${s}"`);
      const [, sign, int, frac = ""] = m;
      const n = BigInt(int + frac) * (sign ? -1n : 1n);
      return new _Q(n, 10n ** BigInt(frac.length));
    }
    add(o) {
      return new _Q(this.n * o.d + o.n * this.d, this.d * o.d);
    }
    sub(o) {
      return new _Q(this.n * o.d - o.n * this.d, this.d * o.d);
    }
    mul(o) {
      return new _Q(this.n * o.n, this.d * o.d);
    }
    div(o) {
      if (o.n === 0n) throw new RangeError("S\u0131f\u0131ra b\xF6lme");
      return new _Q(this.n * o.d, this.d * o.n);
    }
    neg() {
      return new _Q(-this.n, this.d);
    }
    cmp(o) {
      const l = this.n * o.d;
      const r = o.n * this.d;
      return l < r ? -1 : l > r ? 1 : 0;
    }
    eq(o) {
      return this.n === o.n && this.d === o.d;
    }
    isZero() {
      return this.n === 0n;
    }
    sign() {
      return this.n < 0n ? -1 : this.n > 0n ? 1 : 0;
    }
    /** Yukarı yuvarlama (tavan). Sipariş adedi için. */
    ceil() {
      const q = this.n / this.d;
      return this.n % this.d !== 0n && this.n > 0n ? q + 1n : q;
    }
    /** Kesin gösterim: "-571173/10100" */
    toString() {
      return this.d === 1n ? `${this.n}` : `${this.n}/${this.d}`;
    }
    /**
     * YALNIZCA GÖSTERİM içindir. Yarım değerler sıfırdan uzağa yuvarlanır.
     * Hesaplarda kullanılmaz.
     */
    toFixed(digits = 2) {
      const scale = 10n ** BigInt(digits);
      const x = this.n * scale;
      let q = x / this.d;
      const r = abs(x % this.d);
      if (2n * r >= this.d) q += this.n < 0n ? -1n : 1n;
      const neg = q < 0n;
      const s = abs(q).toString().padStart(digits + 1, "0");
      const body = digits === 0 ? s : `${s.slice(0, -digits)}.${s.slice(-digits)}`;
      return (neg ? "-" : "") + body;
    }
  };

  // src/engine/profit.ts
  var STOPAJ_RATE = Q.dec("0.01");
  var AMAZON_FEE_VAT = Q.dec("0.20");

  // src/engine/buybox.ts
  var UNDERCUT_SHARE_MAX = Q.of(1n, 5n);
  var MIN_BELOW_TOLERANCE = Q.of(5n, 100n);

  // src/core/reprice.ts
  var RESEND_AFTER_MS = 60 * 60 * 1e3;
  var REFLECT_WAIT_MS = 60 * 60 * 1e3;
  var CAMPAIGN_FRESH_MS = 30 * 60 * 1e3;
  var MARGIN_STEP = Q.of(1n, 100n);
  var MARGIN_LIMIT = Q.of(99n, 100n);

  // src/core/ty-page.ts
  function tyPriceKurusOf(v) {
    const s = typeof v === "number" && Number.isFinite(v) ? String(v) : typeof v === "string" ? v : "";
    const m = /^([0-9]{1,9})(?:\.([0-9]{1,2}))?$/.exec(s);
    if (!m) return null;
    const k = BigInt(m[1]) * 100n + BigInt((m[2] ?? "").padEnd(2, "0") || "0");
    return k > 0n ? k : null;
  }
  var MARK = 'window["__envoy__SHARED_PROPS"]=';
  var idName = (x) => {
    if (!x || typeof x !== "object") return null;
    const o = x;
    return (typeof o.id === "number" || typeof o.id === "string") && /^[0-9]+$/.test(String(o.id)) && typeof o.name === "string" && o.name.trim() ? { id: String(o.id), name: o.name.trim() } : null;
  };
  function tyPageProduct(html, contentId) {
    const at = html.indexOf(MARK);
    if (at < 0) return { ok: false, why: "veri_yok", detail: "Sayfada \xFCr\xFCn verisi bulunamad\u0131 (Trendyol sayfay\u0131 vermedi ya da sayfa yap\u0131s\u0131 de\u011Fi\u015Fti)." };
    const end = html.indexOf("<\/script>", at);
    if (end < 0) return { ok: false, why: "okunamadi", detail: "\xDCr\xFCn verisi yar\u0131m geldi." };
    let root2;
    try {
      root2 = JSON.parse(html.slice(at + MARK.length, end).trim().replace(/;$/, ""));
    } catch {
      return { ok: false, why: "okunamadi", detail: "\xDCr\xFCn verisi \xE7\xF6z\xFClemedi." };
    }
    const p = root2?.product;
    if (!p || typeof p !== "object") return { ok: false, why: "okunamadi", detail: "\xDCr\xFCn verisinde \xFCr\xFCn yok." };
    if (String(p.id) !== contentId) return { ok: false, why: "baska_urun", detail: `Sayfadaki \xFCr\xFCn no ${String(p.id)}, linkteki ${contentId}.` };
    const seen = /* @__PURE__ */ new Set();
    const variants = [];
    for (const v of Array.isArray(p.variants) ? p.variants : []) {
      const bc = typeof v?.barcode === "string" ? v.barcode.trim() : "";
      if (!bc || seen.has(bc)) continue;
      seen.add(bc);
      const label = [v.beautifiedValue, v.value].find((x) => typeof x === "string" && x.trim());
      const pk = tyPriceKurusOf(v.price?.value);
      variants.push({ barcode: bc, label: label?.trim() ?? "", selected: v.isSelected === true, priceKurus: pk === null ? null : pk.toString() });
    }
    if (!variants.length) return { ok: false, why: "barkod_yok", detail: "Sayfada ilan\u0131n barkodu yok." };
    const attributes = [];
    for (const a of Array.isArray(p.attributes) ? p.attributes : []) {
      const k = idName(a?.key);
      const v = idName(a?.value);
      if (k && v) attributes.push({ keyId: k.id, keyName: k.name, valueId: v.id, valueName: v.name });
    }
    const o = p.merchantListing?.originInfo;
    return {
      ok: true,
      contentId,
      name: typeof p.name === "string" && p.name.trim() ? p.name.trim() : null,
      brand: idName(p.brand),
      category: idName(p.category),
      variants,
      attributes,
      origin: typeof o === "string" && /^[A-Z]{2}$/.test(o) ? o : null
    };
  }

  // src/engine/marketplace-price.ts
  var B1 = Q.of(200n);
  var TY_SERVICE_VAT = Q.dec("0.20");
  var B2 = Q.of(350n);
  var LEN = { centimeters: Q.ONE, millimeters: Q.of(1n, 10n), meters: Q.of(100n), inches: Q.dec("2.54") };
  var WT = { kilograms: Q.ONE, grams: Q.of(1n, 1000n), pounds: Q.dec("0.45359237"), ounces: Q.dec("0.028349523125") };

  // src/core/marketplace.ts
  var TR_OFFSET_MS = 3 * 36e5;
  var TY_SAME_PUSH_MS = 15 * 6e4;
  var MP_MISSING_MS = 24 * 36e5;

  // src/core/ty-join.ts
  var unb64url = (s) => decodeURIComponent(escape(atob(s.replace(/-/g, "+").replace(/_/g, "/"))));
  function tyActiveFromHash(hash) {
    const m = /[#&]aos=([A-Za-z0-9_-]{4,800})/.exec(hash);
    if (!m) return null;
    try {
      const o = JSON.parse(unb64url(m[1]));
      if (typeof o.s !== "string" || !o.s || o.s.length > 80) return null;
      return { sku: o.s, asin: typeof o.a === "string" && /^[A-Z0-9]{10}$/.test(o.a) ? o.a : null, title: typeof o.t === "string" ? o.t.slice(0, 80) : null };
    } catch {
      return null;
    }
  }
  function tyContentIdOfHref(href) {
    const path = href.replace(/^https?:\/\/[^/]+/i, "").split(/[?#]/)[0] ?? "";
    return /-p-([0-9]{1,20})$/.exec(path)?.[1] ?? null;
  }
  function tyJoinSentText(r) {
    const tl = (k) => `${(BigInt(k) / 100n).toLocaleString("tr-TR")},${String(BigInt(k) % 100n).padStart(2, "0")} TL`;
    return r.basis === "bb" ? `G\xF6nderildi \xB7 ${tl(r.price_kurus)} (ilan\u0131n g\xFCncel fiyat\u0131) \xB7 %20 k\xE2r fiyat\u0131 ${tl(r.target_kurus)} \xB7 komisyon %${r.commission_pct}. Trendyol onaylay\u0131nca \xFCr\xFCne kendili\u011Finden ba\u011Flan\u0131r.` : `G\xF6nderildi \xB7 ${tl(r.price_kurus)} (%20 k\xE2r fiyat\u0131; ilan\u0131n fiyat\u0131 daha d\xFC\u015F\xFCk ya da okunamad\u0131) \xB7 komisyon %${r.commission_pct}. Trendyol onaylay\u0131nca \xFCr\xFCne kendili\u011Finden ba\u011Flan\u0131r.`;
  }
  function tyGivenError(kind, v) {
    const s = v.trim();
    if (kind === "komisyon") return /^[0-9]{1,2}([.,][0-9]{1,4})?$/.test(s) ? null : "Komisyon y\xFCzdesi yaz\u0131n (\xF6r. 19 ya da 11,5)";
    return /^[1-9][0-9]{0,2}$/.test(s) ? null : "Desi tam say\u0131 olmal\u0131 (\xF6r. 1)";
  }

  // extension/src/content-ty.ts
  var send = (m) => chrome.runtime.sendMessage(m).catch((e) => ({ ok: false, error: e.message }));
  var KEY = "aos-ty-active";
  function readActive() {
    const fromHash = tyActiveFromHash(location.hash);
    try {
      if (fromHash) sessionStorage.setItem(KEY, JSON.stringify(fromHash));
      const s = sessionStorage.getItem(KEY);
      return fromHash ?? (s ? JSON.parse(s) : null);
    } catch {
      return fromHash;
    }
  }
  var active = readActive();
  function setActive(a) {
    active = a;
    try {
      if (a) sessionStorage.setItem(KEY, JSON.stringify(a));
      else sessionStorage.removeItem(KEY);
    } catch {
    }
    renderHead();
  }
  var host = document.createElement("div");
  host.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:2147483647;";
  var root = host.attachShadow({ mode: "closed" });
  root.innerHTML = `<style>
  .box{font:13px/1.45 system-ui,Segoe UI,Arial,sans-serif;background:#fff;color:#111;border:1px solid #c9ced6;border-radius:10px;box-shadow:0 6px 20px rgba(0,0,0,.2);padding:10px 12px;width:340px;max-height:70vh;overflow:auto}
  .head{display:flex;justify-content:space-between;align-items:center;font-weight:600}
  .x{border:0;background:none;font-size:16px;cursor:pointer;color:#666}
  .act{margin:4px 0 6px;font-size:12px;color:#333}.act b{color:#0f6e63}
  .ok{color:#0a7d32}.info{color:#1f5fa8}.warn{color:#9a5b00}.err{color:#b3261e}.muted{color:#666;font-size:12px}
  button.b{padding:4px 10px;border:1px solid #0f6e63;background:#0f6e63;color:#fff;border-radius:6px;cursor:pointer;font:inherit}
  button.l{border:0;background:none;color:#1f5fa8;cursor:pointer;padding:0;font:inherit;text-decoration:underline}
  button:disabled{opacity:.5;cursor:default}
  label{display:block;margin:6px 0 2px;font-size:12px;color:#333}
  input,select{width:100%;box-sizing:border-box;padding:5px 6px;border:1px solid #c9ced6;border-radius:6px;font:inherit}
  .pick{display:block;width:100%;text-align:left;border:0;border-bottom:1px solid #eee;background:none;padding:5px 2px;cursor:pointer;font:inherit}
  .pick:hover{background:#f3f7f6}
</style><div class="box"><div class="head"><span>AMAZON OS \xB7 Trendyol</span><button class="x" title="K\xFC\xE7\xFClt">\u2013</button></div>
<div id="act" class="act"></div><div id="msg"></div><div id="form"></div></div>`;
  var $ = (id) => root.getElementById(id);
  var minimized = false;
  root.querySelector(".x").addEventListener("click", () => {
    minimized = !minimized;
    for (const id of ["act", "msg", "form"]) $(id).style.display = minimized ? "none" : "";
  });
  function el(tag, props = {}, text) {
    const e = document.createElement(tag);
    Object.assign(e, props);
    if (text !== void 0) e.textContent = text;
    return e;
  }
  function show(text, cls = "info") {
    const m = $("msg");
    m.textContent = text;
    m.className = cls;
    if (!host.isConnected) document.documentElement.appendChild(host);
  }
  function clearForm() {
    $("form").replaceChildren();
  }
  function renderHead() {
    const a = $("act");
    a.replaceChildren();
    if (active) {
      a.append("E\u015Flenecek \xFCr\xFCn: ", el("b", {}, active.title ?? active.sku), ` (${active.asin ?? active.sku}) \xB7 `);
      const c = el("button", { className: "l", type: "button" }, "de\u011Fi\u015Ftir");
      c.addEventListener("click", () => askProduct(null));
      a.append(c);
    } else a.textContent = `E\u015Flenecek \xFCr\xFCn se\xE7ilmedi (programda E\u015Fle \u203A "Trendyol'da ara" ile gelince kendili\u011Finden se\xE7ilir).`;
  }
  function askProduct(then) {
    if (!host.isConnected) document.documentElement.appendChild(host);
    clearForm();
    show("Hangi \xFCr\xFCn\xFCn\xFCz? Ad, SKU ya da ASIN yaz\u0131n.", "info");
    const input = el("input", { placeholder: "\xF6r. 4001 mor / B000KT91Q0" });
    const list = el("div");
    let t;
    input.addEventListener("input", () => {
      clearTimeout(t);
      t = setTimeout(async () => {
        const r = await send({ type: "tyProducts", q: input.value });
        list.replaceChildren();
        if (!r.ok) return list.append(el("div", { className: "err" }, r.error));
        if (!r.data.length) return list.append(el("div", { className: "muted" }, input.value.trim().length < 2 ? "" : "Bulunamad\u0131."));
        for (const p of r.data.slice(0, 12)) {
          const b = el("button", { className: "pick", type: "button" }, `${p.title ?? p.asin} \xB7 ${p.sku}`);
          b.addEventListener("click", () => {
            setActive({ sku: p.sku, asin: p.asin, title: p.title });
            clearForm();
            show("\xDCr\xFCn se\xE7ildi.", "ok");
            then?.();
          });
          list.append(b);
        }
      }, 300);
    });
    $("form").append(input, list);
    input.focus();
  }
  var owned = /* @__PURE__ */ new Set();
  var ownedItems = /* @__PURE__ */ new Map();
  var freeOf = (id) => (ownedItems.get(id) ?? []).filter((x) => x.sku === null);
  var otherOf = (id) => active ? (ownedItems.get(id) ?? []).filter((x) => x.sku !== null && x.sku !== active.sku) : [];
  var mineOf = (id) => active ? (ownedItems.get(id) ?? []).some((x) => x.sku === active.sku) : false;
  var ownState = (id) => !owned.has(id) ? "" : freeOf(id).length ? "bagsiz" : !mineOf(id) && otherOf(id).length ? `baska:${active?.sku ?? ""}` : `var:${active?.sku ?? ""}`;
  var sentText = /* @__PURE__ */ new Map();
  var busy = false;
  async function join(id, href, given = {}, page, variant) {
    if (busy) return;
    if (!active) return askProduct(() => void join(id, href));
    clearForm();
    busy = true;
    const t0 = Date.now();
    const tick = setInterval(() => show(`${page ? "G\xF6nderiliyor" : "\u0130lan okunuyor"} \xB7 ${Math.round((Date.now() - t0) / 1e3)} sn`, "muted"), 1e3);
    try {
      if (!page) {
        show("\u0130lan okunuyor\u2026", "muted");
        const res = await fetch(new URL(href, location.origin).href.split("#")[0], { credentials: "omit" });
        const p = res.ok ? tyPageProduct(await res.text(), id) : { ok: false, why: "veri_yok", detail: `Trendyol sayfay\u0131 vermedi (durum ${res.status}).` };
        if (!p.ok) return show(`\u0130lan okunamad\u0131: ${p.detail} Programdaki E\u015Fle penceresinde ilan\u0131n barkodunu elle yazabilirsiniz.`, "err");
        page = p;
      }
      if (!variant) {
        if (page.variants.length > 1) return pickVariant(id, href, page);
        variant = page.variants[0];
      }
      show("G\xF6nderiliyor\u2026", "muted");
      const r = await send({ type: "tyJoin", body: {
        sku: active.sku,
        barcode: variant.barcode,
        category_id: page.category?.id ?? "",
        brand: page.brand,
        name: page.name,
        attributes: page.attributes,
        origin: page.origin,
        bb_kurus: variant.priceKurus,
        given
      } });
      if (!r.ok) return show(r.error, "err");
      const d = r.data;
      if (!d.ok) return show(d.message ?? "G\xF6nderilemedi", "err");
      if (d.sent) {
        const text = tyJoinSentText(d);
        sentText.set(id, text);
        show(text, "ok");
        return paint();
      }
      askMissing(id, href, page, variant, d.missing, given);
    } catch (e) {
      show(e.message, "err");
    } finally {
      clearInterval(tick);
      busy = false;
    }
  }
  function pickVariant(id, href, page) {
    show(`Bu ilanda ${page.variants.length} se\xE7enek var; hangisine ekleneceksiniz?`, "warn");
    for (const v of page.variants) {
      const b = el("button", { className: "pick", type: "button" }, `${v.label || "(ads\u0131z)"} \xB7 ${v.barcode}`);
      b.addEventListener("click", () => void join(id, href, {}, page, v));
      $("form").append(b);
    }
  }
  var ATTR_KEY = "aos-ty-attrs";
  function savedAttrs(categoryId) {
    if (!categoryId) return {};
    try {
      const all = JSON.parse(localStorage.getItem(ATTR_KEY) ?? "{}");
      return all[categoryId] && typeof all[categoryId] === "object" ? all[categoryId] : {};
    } catch {
      return {};
    }
  }
  function saveAttrs(categoryId, attrs) {
    if (!categoryId || Object.keys(attrs).length === 0) return;
    try {
      const all = JSON.parse(localStorage.getItem(ATTR_KEY) ?? "{}");
      all[categoryId] = { ...all[categoryId] ?? {}, ...attrs };
      localStorage.setItem(ATTR_KEY, JSON.stringify(all));
    } catch {
    }
  }
  function askMissing(id, href, page, variant, missing, given) {
    clearForm();
    const catId = page.category?.id;
    const remembered = savedAttrs(catId);
    let prefilled = 0;
    const blocked = missing.filter((m) => !m.promptable);
    if (blocked.length) {
      show(`G\xF6nderilmedi: ${blocked.map((m) => m.label).join(" \xB7 ")}`, "err");
      return;
    }
    show("G\xF6nderilmedi: \u015Fu bilgiler eksik. Girin, kald\u0131\u011F\u0131 yerden s\xFCrer.", "warn");
    const form = $("form");
    const readers = [];
    const attrReaders = /* @__PURE__ */ new Set();
    const next = { ...given, attrs: { ...given.attrs ?? {} } };
    let vat = null;
    for (const m of missing) {
      form.append(el("label", {}, m.label));
      if (m.kind === "komisyon" || m.kind === "desi") {
        const kind = m.kind;
        const i = el("input", { placeholder: kind === "komisyon" ? "\xF6r. 19" : "\xF6r. 1" });
        form.append(i);
        readers.push(() => {
          const e = tyGivenError(kind, i.value);
          if (!e) next[kind === "komisyon" ? "commission" : "desi"] = i.value.trim().replace(",", ".");
          return e;
        });
      } else if (m.kind === "kdv") {
        const s = el("select");
        for (const [v, t] of [["", "se\xE7in"], ["0.01", "%1"], ["0.10", "%10"], ["0.20", "%20"]]) s.append(el("option", { value: v }, t));
        form.append(s);
        readers.push(() => s.value ? (vat = s.value, null) : "KDV oran\u0131n\u0131 se\xE7in");
      } else if (m.kind === "marka") {
        const s = el("select");
        s.append(el("option", { value: "" }, m.options.length ? "se\xE7in" : "Trendyol'da bu adla marka bulunamad\u0131"));
        for (const o of m.options) s.append(el("option", { value: o.id }, o.name));
        form.append(s);
        readers.push(() => s.value ? (next.brand_id = s.value, null) : "Markay\u0131 se\xE7in");
      } else if (m.kind === "ozellik") {
        if (m.options.length) {
          const s = el("select");
          s.append(el("option", { value: "" }, "se\xE7in"));
          for (const o of m.options) s.append(el("option", { value: o.id }, o.value));
          const was = remembered[m.id]?.valueId;
          if (was && m.options.some((o) => o.id === was)) {
            s.value = was;
            prefilled++;
          }
          form.append(s);
          const rd = () => s.value ? (next.attrs[m.id] = { valueId: s.value }, null) : `${m.label} se\xE7in`;
          readers.push(rd);
          attrReaders.add(rd);
        } else {
          const i = el("input");
          if (remembered[m.id]?.custom) {
            i.value = remembered[m.id].custom;
            prefilled++;
          }
          form.append(i);
          const rd = () => m.allowCustom && i.value.trim() ? (next.attrs[m.id] = { custom: i.value.trim() }, null) : `${m.label} yaz\u0131n`;
          readers.push(rd);
          attrReaders.add(rd);
        }
      }
    }
    const err = el("div", { className: "err" });
    const go = el("button", { className: "b", type: "button" }, "Kaydet ve g\xF6nder");
    go.style.marginTop = "8px";
    const submit = async (skipAttrs) => {
      const errors = readers.map((f) => {
        const e = f();
        return skipAttrs && attrReaders.has(f) ? null : e;
      }).filter((x) => !!x);
      if (errors.length) return void (err.textContent = errors.join(" \xB7 "));
      if (skipAttrs) next.skip_attrs = true;
      else delete next.skip_attrs;
      go.disabled = true;
      if (vat) {
        if (!active?.asin) return void (err.textContent = "\xDCr\xFCn\xFCn ASIN'i bilinmiyor: KDV oran\u0131n\u0131 programda \xFCr\xFCn kart\u0131ndan girin");
        const r = await send({ type: "tyVat", asin: active.asin, vat });
        if (!r.ok) {
          go.disabled = false;
          return void (err.textContent = r.error);
        }
      }
      saveAttrs(catId, next.attrs);
      void join(id, href, next, page, variant);
    };
    go.addEventListener("click", () => void submit(false));
    form.append(err, go);
    if (prefilled > 0) show(`G\xF6nderilmedi: \u015Fu bilgiler eksik. ${prefilled} alan bu kategorideki \xF6nceki se\xE7iminizle dolduruldu \u2014 kontrol edip g\xF6nderin (\xFCr\xFCne g\xF6re de\u011Fi\u015Feni d\xFCzeltin).`, "warn");
  }
  function askMove(id) {
    if (!active) return askProduct(() => askMove(id));
    const o = otherOf(id);
    if (o.length === 0) return;
    clearForm();
    show(`Bu ilan programda ba\u015Fka bir kayda ba\u011Fl\u0131. "${active.title ?? active.sku}" (${active.sku}) \xFCr\xFCn\xFCne ta\u015F\u0131ns\u0131n m\u0131? Eski kay\u0131t bu ilandan ayr\u0131l\u0131r; stok bundan sonra ${active.sku} \xFCr\xFCn\xFCn\xFCn deposundan g\xF6nderilir.`, "warn");
    for (const x of o) {
      const b = el("button", { className: "b", type: "button" }, `Evet, ta\u015F\u0131: ${x.title ?? x.barcode} (\u015Fimdi ${x.sku})`);
      b.style.display = "block";
      b.style.marginTop = "6px";
      b.addEventListener("click", () => void moveOwned(x));
      $("form").append(b);
    }
  }
  async function moveOwned(x) {
    if (busy || !active) return;
    clearForm();
    busy = true;
    show("Ta\u015F\u0131n\u0131yor\u2026", "muted");
    try {
      const was = x.sku;
      const r = await send({ type: "tyLink", barcode: x.barcode, sku: active.sku });
      if (!r.ok) return show(`Ta\u015F\u0131namad\u0131: ${r.error}`, "err");
      x.sku = active.sku;
      show(`Ta\u015F\u0131nd\u0131: "${x.title ?? x.barcode}" art\u0131k ${active.sku} \xFCr\xFCn\xFCne ba\u011Fl\u0131 (\xF6nce ${was}). \xD6NEML\u0130: programda Pazaryerleri ekran\u0131n\u0131 yenileyin; bu \xFCr\xFCn\xFCn deposu "ba\u011Fl\u0131 de\u011Fil" g\xF6r\xFCn\xFCyorsa depoyu se\xE7in \u2014 yoksa ilana stok g\xF6nderilmez.`, "ok");
    } finally {
      busy = false;
      pageShown = null;
      paint();
    }
  }
  async function linkOwned(id, barcode) {
    if (busy) return;
    if (!active) return askProduct(() => void linkOwned(id, barcode));
    const free = freeOf(id);
    if (free.length === 0) return;
    const pick = barcode ? free.find((x) => x.barcode === barcode) : free.length === 1 ? free[0] : void 0;
    if (!pick) {
      clearForm();
      show(`Bu ilanda ${free.length} ba\u011Fs\u0131z se\xE7enek var. "${active.title ?? active.sku}" hangisine ba\u011Flans\u0131n?`, "warn");
      for (const x of free) {
        const b = el("button", { className: "b", type: "button" }, `${x.title ?? ""} \xB7 ${x.barcode}`.trim());
        b.style.display = "block";
        b.style.marginTop = "6px";
        b.addEventListener("click", () => void linkOwned(id, x.barcode));
        $("form").append(b);
      }
      return;
    }
    clearForm();
    busy = true;
    show("Ba\u011Flan\u0131yor\u2026", "muted");
    try {
      const r = await send({ type: "tyLink", barcode: pick.barcode, sku: active.sku });
      if (!r.ok) return show(`Ba\u011Flanamad\u0131: ${r.error}`, "err");
      pick.sku = active.sku;
      show(`Ba\u011Fland\u0131: "${pick.title ?? pick.barcode}" \u2192 ${active.title ?? active.sku} (${active.sku}). D\u0130KKAT: \xFCr\xFCn\xFCn deposu se\xE7iliyse depo sto\u011Fu bu ilana g\xF6nderilmeye ba\u015Flar ve ilan Trendyol'daki mevcut fiyat\u0131yla sat\u0131\u015Fa a\xE7\u0131labilir \u2014 programda Pazaryerleri ekran\u0131ndan fiyat\u0131 kontrol edin.`, "ok");
    } finally {
      busy = false;
      pageShown = null;
      paint();
    }
  }
  var MARK2 = "data-aos-ty";
  var checked = /* @__PURE__ */ new Set();
  var pillCss = "position:absolute;left:50%;top:6px;transform:translateX(-50%);z-index:6;padding:2px 9px;border-radius:10px;white-space:nowrap;box-shadow:0 1px 4px rgba(0,0,0,.25);font:600 11px/16px system-ui,Segoe UI,Arial,sans-serif;";
  function badgeFor(id, href) {
    if (owned.has(id) && freeOf(id).length > 0) {
      const b2 = el("button", { type: "button", title: "AMAZON OS: bu ilan hesab\u0131n\u0131zda var ama programda bir \xFCr\xFCne ba\u011Fl\u0131 de\u011Fil. T\u0131klay\u0131nca se\xE7ili \xFCr\xFCne ba\u011Flan\u0131r; sonra depo sto\u011Fu bu ilana g\xF6nderilir (fiyat\u0131 programdan kontrol edin)." }, "\u{1F517} Listenizde \xB7 ba\u011Fla");
      b2.style.cssText = `${pillCss}background:#fff7e0;color:#8a5a00;border:1px solid #e3c36a;cursor:pointer;`;
      b2.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        void linkOwned(id);
      });
      return b2;
    }
    if (owned.has(id) && !mineOf(id) && otherOf(id).length > 0) {
      const o = otherOf(id);
      const b2 = el("button", { type: "button", title: `AMAZON OS: bu ilan programda ba\u015Fka bir kayda ba\u011Fl\u0131 (${[...new Set(o.map((x) => x.sku))].join(", ")}). T\u0131klay\u0131nca se\xE7ili \xFCr\xFCne ta\u015F\u0131may\u0131 sorar.` }, "\u21AA Ba\u015Fka kayda ba\u011Fl\u0131 \xB7 ta\u015F\u0131");
      b2.style.cssText = `${pillCss}background:#fff0e6;color:#9a4a00;border:1px solid #f0b98a;cursor:pointer;`;
      b2.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        askMove(id);
      });
      return b2;
    }
    if (owned.has(id)) {
      const skus = [...new Set((ownedItems.get(id) ?? []).map((x) => x.sku).filter((x) => !!x))];
      const s = el("span", { title: skus.length ? `Programda ba\u011Fl\u0131 \xFCr\xFCn: ${skus.join(", ")}` : "" }, "\u2713 Listenizde var");
      s.style.cssText = `${pillCss}background:#e4f4e9;color:#0a7d32;border:1px solid #9fd5b1;`;
      return s;
    }
    if (sentText.has(id)) {
      const s = el("span", { title: sentText.get(id) }, "\u23F3 G\xF6nderildi \xB7 onay bekleniyor");
      s.style.cssText = `${pillCss}background:#eef4fc;color:#1f5fa8;border:1px solid #b9d4f5;`;
      return s;
    }
    const b = el("button", { type: "button", title: "AMAZON OS: bu ilana sat\u0131c\u0131 olarak eklen (\xFCr\xFCn ilan\u0131n barkoduyla g\xF6nderilir)" }, "\u21C4 E\u015Fle");
    b.style.cssText = `${pillCss}background:#0f6e63;color:#fff;border:1px solid #0f6e63;cursor:pointer;`;
    b.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      void join(id, href);
    });
    return b;
  }
  function cardLinks() {
    const out = [];
    for (const a of Array.from(document.querySelectorAll('a[href*="-p-"]'))) {
      const id = tyContentIdOfHref(a.getAttribute("href") ?? "");
      if (id && a.querySelector("img")) out.push({ a, id });
    }
    return out;
  }
  function paint() {
    for (const { a, id } of cardLinks()) {
      if (!checked.has(id)) continue;
      const state = owned.has(id) ? ownState(id) : sentText.has(id) ? "gonderildi" : "esle";
      const old = a.querySelector(`:scope > [${MARK2}]`);
      if (old?.dataset.aosState === state && old.getAttribute(MARK2) === id) continue;
      old?.remove();
      const b = badgeFor(id, a.getAttribute("href") ?? "");
      b.setAttribute(MARK2, id);
      b.dataset.aosState = state;
      if (getComputedStyle(a).position === "static") a.style.position = "relative";
      a.appendChild(b);
    }
    paintPage();
  }
  var pageShown = null;
  function paintPage() {
    const id = tyContentIdOfHref(location.pathname);
    if (!id || !checked.has(id) || busy) return;
    const state = `${id}:${owned.has(id) ? ownState(id) : sentText.has(id) ? "gonderildi" : "esle"}:${active?.sku ?? ""}`;
    if (pageShown === state) return;
    pageShown = state;
    clearForm();
    if (owned.has(id) && freeOf(id).length > 0) {
      show("Bu ilan hesab\u0131n\u0131zda var ama programda bir \xFCr\xFCne ba\u011Fl\u0131 de\u011Fil.", "warn");
      const b2 = el("button", { className: "b", type: "button" }, "\u{1F517} Bu \xFCr\xFCne ba\u011Fla");
      b2.addEventListener("click", () => void linkOwned(id));
      $("form").append(b2);
      return;
    }
    if (owned.has(id) && !mineOf(id) && otherOf(id).length > 0) return askMove(id);
    if (owned.has(id)) {
      const to = [...new Set((ownedItems.get(id) ?? []).map((x) => x.sku).filter((x) => x !== null))];
      return show(`\u2713 Bu ilan listenizde var ve programda ${to.length ? `${to.join(", ")} \xFCr\xFCn\xFCne` : "bir \xFCr\xFCne"} ba\u011Fl\u0131. Yap\u0131lacak bir \u015Fey yok.`, "ok");
    }
    if (sentText.has(id)) return show(sentText.get(id), "ok");
    if (/Aradığınız Sayfa Bulunamadı/i.test(document.body?.innerText ?? "")) {
      return show(`Bu ilan\u0131n Trendyol'da a\xE7\u0131k sayfas\u0131 yok (sat\u0131\u015Fta de\u011Fil); buradan e\u015Flenemez. Sat\u0131c\u0131 panelinde "Trendyol Katalo\u011Fundan Ekle" ile ekleyin, programda \xFCr\xFCn\xFCn sat\u0131r\u0131ndaki "elle" ba\u011Flant\u0131s\u0131na bu adresi yap\u0131\u015Ft\u0131r\u0131n: ilan hesab\u0131n\u0131zda g\xF6r\xFCn\xFCnce kendili\u011Finden e\u015Flenir.`, "warn");
    }
    show("Bu ilan listenizde yok.", "warn");
    const b = el("button", { className: "b", type: "button" }, "\u21C4 Bu ilana e\u015Fle");
    b.addEventListener("click", () => void join(id, location.pathname));
    $("form").append(b);
  }
  var scanning = false;
  async function scan() {
    if (scanning) return;
    scanning = true;
    try {
      const here = tyContentIdOfHref(location.pathname);
      const ids = [.../* @__PURE__ */ new Set([...cardLinks().map((x) => x.id), ...here ? [here] : []])].filter((x) => !checked.has(x));
      for (let i = 0; i < ids.length; i += 150) {
        const part = ids.slice(i, i + 150);
        const r = await send({ type: "tyStatuses", ids: part });
        if (!r.ok) {
          show(r.error, "err");
          return;
        }
        for (const x of r.data) owned.add(x);
        const od = await send({ type: "tyOwned", ids: r.data });
        if (od.ok) for (const x of od.data) ownedItems.set(x.id, [...(ownedItems.get(x.id) ?? []).filter((y) => y.barcode !== x.barcode), { barcode: x.barcode, title: x.title, sku: x.sku }]);
        for (const x of part) checked.add(x);
      }
      paint();
    } finally {
      scanning = false;
    }
  }
  renderHead();
  if (active || tyContentIdOfHref(location.pathname)) document.documentElement.appendChild(host);
  void scan();
  var deb;
  new MutationObserver(() => {
    clearTimeout(deb);
    deb = setTimeout(() => {
      const a = readActive();
      if (a && a.sku !== active?.sku) setActive(a);
      void scan();
    }, 600);
  }).observe(document.documentElement, { childList: true, subtree: true });
})();
