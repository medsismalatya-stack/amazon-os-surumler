"use strict";
(() => {
  // src/engine/rational.ts
  var abs = (x) => x < 0n ? -x : x;
  var gcd = (a, b) => {
    a = abs(a);
    b = abs(b);
    while (b !== 0n) [a, b] = [b, a % b];
    return a;
  };
  var toBigInt = (x, label) => {
    if (typeof x === "bigint") return x;
    if (!Number.isSafeInteger(x)) {
      throw new RangeError(`${label} tam say\u0131 olmal\u0131: ${x}`);
    }
    return BigInt(x);
  };
  var Q = class _Q {
    n;
    d;
    constructor(n, d) {
      if (d === 0n) throw new RangeError("Payda s\u0131f\u0131r olamaz");
      if (d < 0n) {
        n = -n;
        d = -d;
      }
      const g = gcd(n, d) || 1n;
      this.n = n / g;
      this.d = d / g;
    }
    static ZERO = new _Q(0n, 1n);
    static ONE = new _Q(1n, 1n);
    /** Tam sayı veya kesir: Q.of(3), Q.of(59700, 101) */
    static of(n, d = 1n) {
      return new _Q(toBigInt(n, "pay"), toBigInt(d, "payda"));
    }
    /** Kuruş cinsinden tutar → TL. Q.kurus(12900) = 129 */
    static kurus(k) {
      return new _Q(toBigInt(k, "kuru\u015F"), 100n);
    }
    /** Ondalık metin → kesin kesir. Q.dec("0.09") = 9/100. Virgül kabul edilmez. */
    static dec(s) {
      const m = /^(-)?(\d+)(?:\.(\d+))?$/.exec(s.trim());
      if (!m) throw new RangeError(`Ge\xE7ersiz ondal\u0131k say\u0131: "${s}"`);
      const [, sign, int, frac = ""] = m;
      const n = BigInt(int + frac) * (sign ? -1n : 1n);
      return new _Q(n, 10n ** BigInt(frac.length));
    }
    add(o) {
      return new _Q(this.n * o.d + o.n * this.d, this.d * o.d);
    }
    sub(o) {
      return new _Q(this.n * o.d - o.n * this.d, this.d * o.d);
    }
    mul(o) {
      return new _Q(this.n * o.n, this.d * o.d);
    }
    div(o) {
      if (o.n === 0n) throw new RangeError("S\u0131f\u0131ra b\xF6lme");
      return new _Q(this.n * o.d, this.d * o.n);
    }
    neg() {
      return new _Q(-this.n, this.d);
    }
    cmp(o) {
      const l = this.n * o.d;
      const r = o.n * this.d;
      return l < r ? -1 : l > r ? 1 : 0;
    }
    eq(o) {
      return this.n === o.n && this.d === o.d;
    }
    isZero() {
      return this.n === 0n;
    }
    sign() {
      return this.n < 0n ? -1 : this.n > 0n ? 1 : 0;
    }
    /** Yukarı yuvarlama (tavan). Sipariş adedi için. */
    ceil() {
      const q = this.n / this.d;
      return this.n % this.d !== 0n && this.n > 0n ? q + 1n : q;
    }
    /** Kesin gösterim: "-571173/10100" */
    toString() {
      return this.d === 1n ? `${this.n}` : `${this.n}/${this.d}`;
    }
    /**
     * YALNIZCA GÖSTERİM içindir. Yarım değerler sıfırdan uzağa yuvarlanır.
     * Hesaplarda kullanılmaz.
     */
    toFixed(digits = 2) {
      const scale = 10n ** BigInt(digits);
      const x = this.n * scale;
      let q = x / this.d;
      const r = abs(x % this.d);
      if (2n * r >= this.d) q += this.n < 0n ? -1n : 1n;
      const neg = q < 0n;
      const s = abs(q).toString().padStart(digits + 1, "0");
      const body = digits === 0 ? s : `${s.slice(0, -digits)}.${s.slice(-digits)}`;
      return (neg ? "-" : "") + body;
    }
  };

  // src/engine/profit.ts
  var STOPAJ_RATE = Q.dec("0.01");
  var AMAZON_FEE_VAT = Q.dec("0.20");

  // src/engine/buybox.ts
  var UNDERCUT_SHARE_MAX = Q.of(1n, 5n);
  var MIN_BELOW_TOLERANCE = Q.of(5n, 100n);

  // src/core/ty-visits.ts
  function trInt(s) {
    const t2 = (s ?? "").trim();
    if (!/^\d{1,3}(\.\d{3})*$/.test(t2)) return null;
    return Number(t2.replace(/\./g, ""));
  }
  function trMoneyKurus(s) {
    const m = /^(\d{1,3}(?:\.\d{3})*)(?:,(\d{1,2}))?\s*₺$/.exec((s ?? "").trim());
    if (!m) return null;
    return String(BigInt(m[1].replace(/\./g, "")) * 100n + BigInt((m[2] ?? "0").padEnd(2, "0")));
  }
  function tyVisitRange(s) {
    const m = /^(\d{2})\/(\d{2})\/(\d{4})\s*-\s*(\d{2})\/(\d{2})\/(\d{4})$/.exec((s ?? "").trim());
    if (!m) return null;
    const from = `${m[3]}-${m[2]}-${m[1]}`;
    const to = `${m[6]}-${m[5]}-${m[4]}`;
    return from <= to ? { from, to } : null;
  }
  function tyVisitRow(cells, href, title) {
    const id = /-p-(\d{1,20})(?:[/?#]|$)/.exec(href ?? "")?.[1] ?? null;
    if (!id) return { ok: false, why: "\xFCr\xFCn numaras\u0131 yok" };
    if (cells.length < 10) return { ok: false, why: `s\xFCtun say\u0131s\u0131 ${cells.length} (10 bekleniyor)` };
    const model = /Model Kodu:\s*\n?\s*([^\n]+)/.exec(cells[0] ?? "")?.[1]?.trim() ?? null;
    const n = [1, 2, 3, 4, 5, 6, 8].map((i) => trInt(cells[i]));
    const rev = trMoneyKurus(cells[9]);
    if (n.some((x) => x === null) || rev === null) return { ok: false, why: "say\u0131 okunamad\u0131" };
    const [views, fav_gross, fav_active, seller_views, cart, orders, sales] = n;
    return { ok: true, row: { content_id: id, model_code: model || null, title: title?.trim() || null, views, fav_gross, fav_active, seller_views, cart, orders, sales, revenue_kurus: rev } };
  }

  // extension/src/content-typ.ts
  var PATH = "/business-advisor/sales-enhancer/visit-fav";
  var send = (m) => chrome.runtime.sendMessage(m).catch((e) => ({ ok: false, error: e.message }));
  var host = document.createElement("div");
  host.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:2147483647;";
  var root = host.attachShadow({ mode: "closed" });
  root.innerHTML = `<style>
  .box{font:13px/1.45 system-ui,Segoe UI,Arial,sans-serif;background:#fff;color:#111;border:1px solid #c9ced6;border-radius:10px;box-shadow:0 6px 20px rgba(0,0,0,.2);padding:10px 12px;width:320px}
  .head{font-weight:600;margin-bottom:4px}.ok{color:#0a7d32}.err{color:#b3261e}.muted{color:#666;font-size:12px}
</style><div class="box"><div class="head">AMAZON OS \xB7 G\xF6r\xFCnt\xFClenme</div><div id="msg"></div><div id="sub" class="muted"></div></div>`;
  var $ = (id) => root.getElementById(id);
  var sent = /* @__PURE__ */ new Set();
  var rangeKey = "";
  var busy = false;
  function rangeText() {
    const b = [...document.querySelectorAll("bl-input")].find((x) => x.getAttribute("label") === "Tarih Aral\u0131\u011F\u0131 Se\xE7in");
    return b?.getAttribute("value") ?? b?.shadowRoot?.querySelector("input")?.value ?? null;
  }
  function totalCount() {
    const m = /Toplam (\d+) ürün bilgisi/.exec(document.body.innerText);
    return m ? Number(m[1]) : null;
  }
  function show(msg, cls, sub = "") {
    if (!host.isConnected) document.documentElement.appendChild(host);
    const m = $("msg");
    m.textContent = msg;
    m.className = cls;
    $("sub").textContent = sub;
  }
  async function scan() {
    if (location.pathname !== PATH || busy) return;
    const range = tyVisitRange(rangeText());
    if (!range) return;
    const key = `${range.from}|${range.to}`;
    if (key !== rangeKey) {
      rangeKey = key;
      sent.clear();
    }
    const rows = [];
    let bad = 0;
    for (const tr of document.querySelectorAll("bl-table-row")) {
      const info = tr.querySelector("sc-product-info");
      if (!info) continue;
      const cells = [...tr.querySelectorAll("bl-table-cell")].map((c) => c.innerText.trim());
      const r = tyVisitRow(cells, info.getAttribute("href"), info.getAttribute("product-title"));
      if (!r.ok) {
        bad++;
        continue;
      }
      if (!sent.has(r.row.content_id)) rows.push(r.row);
    }
    const total = totalCount();
    const d = (s) => `${s.slice(8, 10)}.${s.slice(5, 7)}.${s.slice(0, 4)}`;
    if (!rows.length) {
      if (sent.size) show(`${sent.size}${total !== null ? ` / ${total}` : ""} \xFCr\xFCn okundu`, "ok", `${d(range.from)} \u2013 ${d(range.to)}${total !== null && sent.size < total ? " \xB7 di\u011Fer sayfalar i\xE7in sayfa numaras\u0131na t\u0131klay\u0131n" : ""}${bad ? ` \xB7 ${bad} sat\u0131r okunamad\u0131` : ""}`);
      return;
    }
    busy = true;
    try {
      show("Okunuyor\u2026", "muted", `${rows.length} yeni \xFCr\xFCn`);
      const r = await send({ type: "tyVisits", from: range.from, to: range.to, rows });
      if (!r.ok) return show(`Kaydedilemedi: ${r.error}`, "err", "Eklenti simgesinden AMAZON OS hesab\u0131yla giri\u015F yapt\u0131\u011F\u0131n\u0131zdan emin olun.");
      for (const x of rows) sent.add(x.content_id);
      show(
        `${sent.size}${total !== null ? ` / ${total}` : ""} \xFCr\xFCn okundu \u2713`,
        "ok",
        `${d(range.from)} \u2013 ${d(range.to)} \xB7 programda Pazaryerleri \u203A Trendyol${total !== null && sent.size < total ? " \xB7 di\u011Fer sayfalar i\xE7in sayfa numaras\u0131na t\u0131klay\u0131n" : ""}${bad ? ` \xB7 ${bad} sat\u0131r okunamad\u0131` : ""}`
      );
    } finally {
      busy = false;
    }
  }
  var t;
  new MutationObserver(() => {
    clearTimeout(t);
    t = setTimeout(() => void scan(), 1200);
  }).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  setTimeout(() => void scan(), 2e3);
})();
